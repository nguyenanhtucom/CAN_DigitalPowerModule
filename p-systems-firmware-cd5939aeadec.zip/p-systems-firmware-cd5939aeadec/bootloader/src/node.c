/**
 *
 * Author: Stou Sandalski <stou@p-systems.io>
 * Copyright (c) 2021 - Pomegranate Systems LLC
 *
 * License: MIT and 3-Clause BSD (See LICENSE.md)
 *
 * Description: Handle "network traffic" from UAVCAN
 *
 */


#include "node.h"

#include <stddef.h>
#include <stdint.h>
#include <string.h>

#include <stm32_util.h>
#include <uavcan_v0.h>

#include "main.h"
#include "params.h"
#include "bootloader.h"

/**
 * Globals
 */

extern uint32_t System_Tick;

extern boot_info_t boot_info;
extern node_info_t node;
extern factory_info_t factory_info;

/**
 * CANbus Reception Filters {id, mask}
 */

uint32_t can_filters[][2] = {
    {UAVCAN_PROTOCOL_GET_NODE_INFO_FILTER_ID, UAVCAN_PROTOCOL_GET_NODE_INFO_FILTER_MASK},
    {UAVCAN_PROTOCOL_GET_TRANSPORT_STATS_FILTER_ID, UAVCAN_PROTOCOL_GET_TRANSPORT_STATS_FILTER_MASK},
    {UAVCAN_PROTOCOL_PARAM_FILTER_ID, UAVCAN_PROTOCOL_PARAM_FILTER_MASK},
    {UAVCAN_PROTOCOL_RESTART_NODE_FILTER_ID, UAVCAN_PROTOCOL_RESTART_NODE_FILTER_MASK},
    {UAVCAN_PROTOCOL_FILE_BEGIN_FIRMWARE_UPDATE_FILTER_ID, UAVCAN_PROTOCOL_FILE_BEGIN_FIRMWARE_UPDATE_FILTER_MASK},
    {UAVCAN_PROTOCOL_FILE_READ_FILTER_ID, UAVCAN_PROTOCOL_FILE_READ_FILTER_MASK}
#if ENABLE_OPTION_BYTE_WRITE
    , {IO_P_SYSTEMS_DEVICE_WRITE_OPTION_BYTES_FILTER_ID, IO_P_SYSTEMS_DEVICE_WRITE_OPTION_BYTES_FILTER_MASK}
#endif
};

/**
 * Request Handling
 */

request_queue_t queue;

// Parameter handling
parameter_getset_t param_get_set;

extern can_params_t can_params;
extern uavcan_init_t uavcan_init;

// File IO
uint8_t file_read_last_error;
uint32_t file_buffer_length = 0;
uint8_t file_read_buffer[FILE_BUFFER_SIZE];
uint32_t firmware_update_write_offset;
bool flash_memory_erased;
uint64_t file_remote_offset = 0;

uint32_t file_last_read_timestamp = 0;
uint8_t file_update_retry_count = 0;

// Option byte writer
#if ENABLE_OPTION_BYTE_WRITE
uint8_t obwrite_data[2];
bool enable_option_byte_writer;
#endif

#if ENABLE_PARAMS
// Parameter Handling
uint8_t param_exec_opcode;
parameter_getset_t param_get_set;
bool parameters_unlocked = false;
#endif

extern uint32_t timestamp_led_off_time;

/**
 * Initialize the can interface
 *
 *
 * @param can
 * @param bus_speed
 * @return
 */
bool CANbus_Init(){

  uavcan_init.can_if = CAN;
  uavcan_init.can_filter_if = CAN_FILTER_IF;
  uavcan_init.filter_count = (sizeof(can_filters) / (2 * sizeof(uint32_t)));
  uavcan_init.can_filters = &can_filters[0][0];

  return UAVCAN_Init(&boot_info,
                     &node,
                     &can_params,
                     &uavcan_init);
}


/**
 *
 * @param data_type_id
 * @param is_service
 * @param source_node_id
 * @param priority
 * @param transfer_id
 * @param payload
 * @param payload_len
 */
void UAVCAN_Handle_Message(const uint16_t data_type_id,
                           __attribute__((unused)) const bool is_service,
                           const uint8_t source_node_id,
                           const uint8_t priority,
                           uint8_t transfer_id,
                           uint8_t *payload,
                           uint32_t payload_len){

  size_t firmware_path_len;

  // Dispatch data
  switch(data_type_id){

    case 1: // UAVCAN_PROTOCOL_NODE_ID_ALLOCATION_ID and UAVCAN_PROTOCOL_GET_NODE_INFO_ID

      // If we have no name this message is actually dynamic id resolution
      if(!node.id_valid){
#if ENABLE_DYNAMIC_ID_ALLOCATION
        // uavcan.protocol.dynamic_id.Allocation

        // Need to see if this message is meant for this node
        // by checking how many UUID bytes match
        int uuid_matches = 0;
        for(int i = 0; i < payload_len - 1; ++i){
          if(payload[1 + uuid_matches] != node.uuid[uuid_matches]){
            break;
          }
          ++uuid_matches;
        }

        // Decode message
        if(uuid_matches == 6){
          // Message 2
          Send_Node_ID_Allocation_Request(&node.uuid[6], 6, 0, false);
        }else if(uuid_matches == 12){
          // Message 3
          Send_Node_ID_Allocation_Request(&node.uuid[12], 4, 0, false);
        }else if(uuid_matches == 16){
          node.id = (payload[0] >> 1U);
          node.id_valid = true;
        }else{
          // Something is wrong so reset back to start
          uavcan_init.dynamic_id_allocation_timestamp = 0;
        }
#endif
      }else{
        Request_Queue_Add(&queue,
                          data_type_id,
                          source_node_id,
                          transfer_id,
                          priority,
                          0);
      }

      break;

#if ENABLE_AUTO_BAUD
    case UAVCAN_PROTOCOL_NODE_STATUS_ID:
      uavcan_init.node_status_received = true;
      break;
#endif

    case UAVCAN_PROTOCOL_FILE_BEGIN_FIRMWARE_UPDATE_ID:

      Deserialize_BeginFirmwareUpdate_Request(payload,
                                              payload_len,
                                              &boot_info.server_node_id,
                                              &firmware_path_len,
                                              boot_info.firmware_file_path);

      boot_info.server_node_id = (boot_info.server_node_id == 0) ? source_node_id : boot_info.server_node_id;
      boot_info.firmware_file_path_len = firmware_path_len;

      // Queue up firmware update response
      Request_Queue_Add_Unique(&queue,
                               data_type_id,
                               source_node_id,
                               transfer_id,
                               priority,
                               0);

      break;


    case UAVCAN_PROTOCOL_FILE_READ_ID:
      // uavcan.protocol.file.Read
      // https://uavcan.org/Specification/7._List_of_standard_data_types/#read

      // File error code is the first 2 byte
      file_read_last_error = (payload[0] | (payload[1] << 8));

      if(file_read_last_error == 0){
        // Copy the new data into the main buffer
        memcpy(file_read_buffer, &payload[2], payload_len - 2);
        file_buffer_length = payload_len - 2;

        // Queue up a request to write the data
        Request_Queue_Add_Unique(&queue,
                                 data_type_id,
                                 source_node_id,
                                 transfer_id,
                                 priority,
                                 0);

      }else{
        file_buffer_length = 0;
        node.health = UAVCAN_NODE_HEALTH_WARNING;
        node.vendor_status_code = UAVCAN_VSC_FILE_READ_FAIL;
      }

      break;

#if ENABLE_TRANSPORT_STATS
    case UAVCAN_PROTOCOL_GET_TRANSPORT_STATS_ID:
      // uavcan.protocol.GetTransportStats
      Request_Queue_Add(&queue,
                        data_type_id,
                        source_node_id,
                        transfer_id,
                        priority,
                        0);

      break;
#endif

    case UAVCAN_PROTOCOL_RESTART_NODE_ID:
      // uavcan.protocol.RestartNode

      if(Check_NodeRestart_Request(payload, payload_len)){
        Request_Queue_Add(&queue,
                          data_type_id,
                          source_node_id,
                          transfer_id,
                          priority,
                          0);
      }
      break;

#if ENABLE_PARAMS
    case UAVCAN_PROTOCOL_PARAM_EXECUTE_OPCODE_ID:
      // First byte is the opcode, the rest is a reserved future parameter...
      Request_Queue_Add_Unique(&queue,
                               data_type_id,
                               source_node_id,
                               transfer_id,
                               priority,
                               payload[0]);

      break;

    case UAVCAN_PROTOCOL_PARAM_GET_SET_ID:
      Request_Queue_Add_Unique(&queue,
                               data_type_id,
                               source_node_id,
                               transfer_id,
                               priority,
                               0);

      Deserialize_GetSet_Request(payload,
                                 payload_len,
                                 &param_get_set);
      break;
#endif

#if ENABLE_OPTION_BYTE_WRITE
    case IO_P_SYSTEMS_DEVICE_WRITE_OPTION_BYTES_ID:
      // io.p-systems.OptionByteWrite
      Request_Queue_Add_Unique(&queue,
                               data_type_id,
                               source_node_id,
                               transfer_id,
                               priority,
                               0);

      obwrite_data[0] = payload[0];
      obwrite_data[1] = payload[1];

      break;
#endif

    default:
      break;
  }
}

void Service_Request_Begin_Firmware_Update(request_t *request){
  if(node.mode == UAVCAN_NODE_MODE_SOFTWARE_UPDATE){
    Send_BeginFirmwareUpdate_Response(node.id,
                                      *request,
                                      UAVCAN_PROTOCOL_FILE_BEGIN_FIRMWARE_UPDATE_ERROR_IN_PROGRESS,
                                      "");
  }else{
    node.mode = UAVCAN_NODE_MODE_SOFTWARE_UPDATE;
    node.health = UAVCAN_NODE_HEALTH_OK;
    node.vendor_status_code = 0;

    Send_BeginFirmwareUpdate_Response(node.id,
                                      *request,
                                      UAVCAN_PROTOCOL_FILE_BEGIN_FIRMWARE_UPDATE_ERROR_OK,
                                      "");

    // Start writing firmware... at the beginning
    firmware_update_write_offset = FIRMWARE_BASE_ADDRESS;

    // Trigger erase if file read is successful so that the firmware isn't accidentally
    // erased by a stray firmware update call.
    flash_memory_erased = false;

    file_buffer_length = 0;
    file_remote_offset = 0;
    file_update_retry_count = 0;

    // Setup a file read request
    Send_FileRead_Request(node.id,
                          boot_info.server_node_id,
                          0,
                          file_remote_offset,
                          boot_info.firmware_file_path_len,
                          boot_info.firmware_file_path);
    file_last_read_timestamp = System_Tick;
  }

  // Trigger a new node status message
  node.timestamp = 0;
}

bool Service_Request_File_Read(){

  // No data was sent
  if(file_buffer_length == 0){
#if ENABLE_IMAGE_VERIFY
    if(Verify_Application_Image(FIRMWARE_BASE_ADDRESS)){
      // Transfer is over and the image is good... reboooot!
      NVIC_SystemReset();
    }else{
      node.health = UAVCAN_NODE_HEALTH_ERROR;
      node.vendor_status_code = UAVCAN_VSC_INVALID_IMAGE;
      return false;
    }
#else
    // Otherwise whatever...
    NVIC_SystemReset();
#endif
  }

  // Erase the memory if we have data but memory has not been erased yet.
  if(!flash_memory_erased){
#if defined(FIRMWARE_PAGE_COUNT)
    flash_memory_erased = Flash_Erase_Pages(FIRMWARE_BASE_ADDRESS, FIRMWARE_PAGE_COUNT);
#elif defined(FIRMWARE_BASE_SECTOR) && defined(FIRMWARE_SECTOR_COUNT)
    flash_memory_erased = Flash_Erase_Sectors(FIRMWARE_BASE_SECTOR, FIRMWARE_SECTOR_COUNT);
#endif
  }

#if defined(LED_RGB_B_GPIO_Port)
  // Indicate YELLOW for software update
  LL_GPIO_ResetOutputPin(LED_RGB_R_GPIO_Port, LED_RGB_R_Pin);
  LL_GPIO_ResetOutputPin(LED_RGB_G_GPIO_Port, LED_RGB_G_Pin);
  LL_GPIO_SetOutputPin(LED_RGB_B_GPIO_Port, LED_RGB_B_Pin);
#elif defined(LED_ACT_GPIO_Port)
  LL_GPIO_ResetOutputPin(LED_ACT_GPIO_Port, LED_ACT_Pin);
#endif
  timestamp_led_off_time = 0;

  if(!Flash_Write_Block(firmware_update_write_offset,
                        file_read_buffer,
                        file_buffer_length)){

    firmware_update_write_offset = 0;
    node.health = UAVCAN_NODE_HEALTH_ERROR;
    node.vendor_status_code = UAVCAN_VSC_FLASH_WRITE_FAIL;
    return false;
  }

  // Advance the firmware offset
  firmware_update_write_offset += file_buffer_length;
  file_remote_offset += file_buffer_length;

  // If there is more data, send a request for new data
  Busy_Wait(10);

  Send_FileRead_Request(node.id,
                        boot_info.server_node_id,
                        0,
                        file_remote_offset,
                        boot_info.firmware_file_path_len,
                        boot_info.firmware_file_path);
  file_last_read_timestamp = System_Tick;
  file_update_retry_count = 0;
  return true;
}


#if ENABLE_PARAMS

bool Service_Param_Exec_Opcode(){
  bool param_ok = false;
  int error = 0;

  // The opcode is stored in the extra data field
  switch(queue.request[queue.top].data){
    case UAVCAN_PROTOCOL_PARAM_OPCODE_ERASE:
      // Load defaults and fall-through to save
      Params_Load_Default_Values(&factory_info);
      break;

    case UAVCAN_PROTOCOL_PARAM_OPCODE_SAVE:

      // Make sure the parameters are unlocked for writing.
      if(!parameters_unlocked){
        break;
      }

      // Disable Write Protection if present
#ifdef EEPROM_WP_GPIO_Port
      LL_GPIO_ResetOutputPin(EEPROM_WP_GPIO_Port, EEPROM_WP_Pin);
#endif
      // Save the data
      param_ok = FactoryInfo_Save(I2C_INTERNAL,
                                  EEPROM_ADDR_7B,
                                  sizeof(factory_info_t),
                                  (uint8_t *) &factory_info);

      // Enable Write Protection if we have it
#ifdef EEPROM_WP_GPIO_Port
      LL_GPIO_SetOutputPin(EEPROM_WP_GPIO_Port, EEPROM_WP_Pin);
#endif
      break;

    default:
      error = 1;
      break;
  }

  return Send_ExecuteOpcode_Response(node.id, queue.request[queue.top], error, param_ok);
}

#endif


void Service_Requests(){

  // If there are no requests pending, return
  if(!queue.request[queue.top].pending){
    return;
  }

  // Dispatch message
  switch(queue.request[queue.top].type_id){

    case UAVCAN_PROTOCOL_FILE_BEGIN_FIRMWARE_UPDATE_ID:
      // uavcan.protocol.file.BeginFirmwareUpdate
      Service_Request_Begin_Firmware_Update(&queue.request[queue.top]);
      break;

    case UAVCAN_PROTOCOL_FILE_READ_ID:
      // uavcan.protocol.file.Read
      Service_Request_File_Read();
      break;

    case UAVCAN_PROTOCOL_GET_NODE_INFO_ID:
      // uavcan.protocol.GetNodeInfo
      Send_GetNodeInfo_Response(&node, queue.request[queue.top]);
      break;

#if ENABLE_TRANSPORT_STATS
    case UAVCAN_PROTOCOL_GET_TRANSPORT_STATS_ID:
      // uavcan.protocol.GetTransportStat
      Send_GetTransportStats_Response(&node, queue.request[queue.top]);
      break;
#endif

#if ENABLE_PARAMS
    case UAVCAN_PROTOCOL_PARAM_EXECUTE_OPCODE_ID:
      // uavcan.protocol.param.ExecuteOpcode
      Service_Param_Exec_Opcode();
      break;

    case UAVCAN_PROTOCOL_PARAM_GET_SET_ID:
      // uavcan.protocol.param.GetSet
      if(Params_Call_Handle_GetSet(node.id,
                                   &param_get_set,
                                   queue.request[queue.top])){
      }
      break;
#endif

    case UAVCAN_PROTOCOL_RESTART_NODE_ID:
      // uavcan.protocol.RestartNode
      Send_NodeRestart_Response(node.id,
                                true,
                                queue.request[queue.top]);
      Busy_Wait(10);
      NVIC_SystemReset();

#if ENABLE_OPTION_BYTE_WRITE
    case IO_P_SYSTEMS_DEVICE_WRITE_OPTION_BYTES_ID:

      Handle_Write_Option_Bytes_Request(node.id,
                                        queue.request[queue.top],
                                        enable_option_byte_writer,
                                        obwrite_data);

      Busy_Wait(100);
      NVIC_SystemReset();
#endif
  }

  Request_Queue_Pop(&queue);
}
