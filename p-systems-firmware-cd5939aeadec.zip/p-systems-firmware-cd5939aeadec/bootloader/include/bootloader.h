/**
 *
 * Author: Stou Sandalski <stou@p-systems.io>
 * Copyright (c) 2021 - Pomegranate Systems LLC

 * License: MIT and 3-Clause BSD (See LICENSE.md)
 *
 * Description: Configuration file for the Pomegranate Systems STM32 Bootloader
 *
 */

#ifndef P_SYSTEMS_BOOTLOADER_BOOTLOADER_H
#define P_SYSTEMS_BOOTLOADER_BOOTLOADER_H

#include <stdbool.h>
#include <stdint.h>

#include "main.h"

/**
 * Compile Options
 */

// Basic tests for checking hardware or porting
#ifndef IS_BLINK_TEST
#define IS_BLINK_TEST                                                 0
#endif

#ifndef IS_TIMINING_TEST
#define IS_TIMING_TEST                                                0
#endif

// Test all calibration parameters (brute force but prevents getting stuck in local minima)
#define IS_COMPREHENSIVE_TEST_MODE                                    1

// Automatically save the factory calibration data after a timing test... not safe
#define IS_AUTO_SAVE_CALIBRATION                                      0

// CANbus Configuration
#define CAN_AUTO_BAUD_RETRY_TIMEOUT_MS                                3000
#define CAN_AUTO_BAUD_MAX_RETRIES                                     10

#define CAN_DEFAULT_BAUD                                              1000
#define CAN_DEFAULT_NODE_ID                                           0

// Boot pin Check boot pin is up over n loops of x ms each
#define BOOT_PIN_LOOP_DELAY_MS                                        50
#define BOOT_PIN_LOOP_COUNT                                           5

// Dynamic Node ID Allocation
#define DYNAMIC_ID_ALLOCATION_RETRY_TIME_MS                           1200
#define DYNAMIC_ID_ALLOCATION_MAX_RETRIES                             10

// Size of firmware update file read buffer, max file chunk is about 256
// so this can be reduced if necessary
#define FILE_BUFFER_SIZE                                              512

// How many times to retry update
#define FILE_GET_MAX_RETRIES                                          10

// How long the activity LED will be on each cycle
#define LED_ACT_ON_TIME_MS                                            50

// Wait this long for file before giving up on a software update
#define SOFTWARE_UPDATE_TIMEOUT_MS                                    500


/**
 * Device Specific Bootloader Configuration
 */
#if defined(ESC_GATEWAY)

#include "esc_gateway.h"

// Boot pin (TP1 - PA13)
#define BOOT_Pin                                                      GPIO_PIN_5
#define BOOT_GPIO_Port                                                GPIOA
#define BOOT_PIN_ACTIVE_LOW                                           true

#define LED_ERROR_Pin                                                 LED_Pin
#define LED_ERROR_GPIO_Port                                           LED_GPIO_Port

// Enable Calibration Parameters
#define ENABLE_FACTORY_INFO                                           1
#define ENABLE_PARAMS                                                 1

#elif defined(FEEDER_CONTROLLER)

#include "feeder_controller.h"

// Boot Switch
#define BOOT_GPIO_Port                                                SW_BOOTLOADER_GPIO_Port
#define BOOT_Pin                                                      SW_BOOTLOADER_Pin
#define BOOT_PIN_ACTIVE_LOW                                           true

// Error LED
#define LED_ERROR_GPIO_Port                                           LED_FAULT_GPIO_Port
#define LED_ERROR_Pin                                                 LED_FAULT_Pin

// Test Mode
#define TEST_MODE_ENTER_GPIO_Port                                     TP_42_GPIO_Port
#define TEST_MODE_ENTER_Pin                                           TP_42_Pin

// I2C
#define ENABLE_I2C                                                    1
#define I2C_INTERNAL_UNIT                                             1
#define I2C_INTERNAL_CLOCK                                            100000
#define I2C_INTERNAL_CLOCK_PERIPH                                     LL_APB1_GRP1_PERIPH_I2C1
#define I2C_INTERNAL_EV_IRQ                                           I2C1_EV_IRQn
#define I2C_INTERNAL_ER_IRQ                                           I2C1_ER_IRQn

// Enable Calibration Parameters
#define ENABLE_FACTORY_INFO                                           1
#define ENABLE_PARAMS                                                 1

#elif defined(INDICATION_CONTROLLER)

#include "indication_controller.h"

// Boot pin (Mode Button - PA3)
#define BOOT_Pin                                                      MOD_SWITCH_Pin
#define BOOT_GPIO_Port                                                MOD_SWITCH_GPIO_Port
#define BOOT_PIN_ACTIVE_LOW                                           true

// LED Configuration
#define LED_ERROR_Pin                                                 LED_STATUS_Pin
#define LED_ERROR_GPIO_Port                                           LED_STATUS_GPIO_Port

#define LED_ACT_Pin                                                   LED_STATUS_Pin
#define LED_ACT_GPIO_Port                                             LED_STATUS_GPIO_Port

// External SDA
#define TEST_MODE_CLOCK_OUTPUT_Pin                                    I2C_EXTERNAL_SDA_Pin
#define TEST_MODE_CLOCK_OUTPUT_GPIO_Port                              I2C_EXTERNAL_SDA_GPIO_Port

// External SCL
#define TEST_MODE_CLOCK_INPUT_Pin                                     I2C_EXTERNAL_SCL_Pin
#define TEST_MODE_CLOCK_INPUT_GPIO_Port                               I2C_EXTERNAL_SCL_GPIO_Port

// I2C
#define ENABLE_I2C                                                    1
#define I2C_INTERNAL_UNIT                                             1
#define I2C_INTERNAL_CLOCK_PERIPH                                     LL_APB1_GRP1_PERIPH_I2C1
#define I2C_INTERNAL_SDA_SET_AFPIN                                    LL_GPIO_SetAFPin_0_7
#define I2C_INTERNAL_SCL_SET_AFPIN                                    I2C_INTERNAL_SDA_SET_AFPIN
#define I2C_INTERNAL_EV_IRQ                                           I2C1_EV_IRQn
#define I2C_INTERNAL_ER_IRQ                                           I2C1_ER_IRQn

// Enable Calibration Parameters
#define ENABLE_FACTORY_INFO                                           1
#define ENABLE_PARAMS                                                 1

#elif defined(RETRACT)

#include "retract_controller.h"

// Boot pin
#define BOOT_Pin                                                      GPIO_PIN_7
#define BOOT_GPIO_Port                                                GPIOB
#define BOOT_PIN_ACTIVE_LOW                                           false

// Status LED
#define LED_ERROR_Pin                                                 LED_PIN
#define LED_ERROR_GPIO_Port                                           LED_GPIO_Port

#elif defined(POWER_MODULE)

#include "power_module.h"

// Boot pin (TP1 - PA13)
#define BOOT_GPIO_Port                                                TP_GPIO_1_GPIO_Port
#define BOOT_Pin                                                      TP_GPIO_1_Pin
#define BOOT_PIN_ACTIVE_LOW                                           true

#define TEST_MODE_ENTER_Pin                                           TP_GPIO_2_Pin
#define TEST_MODE_ENTER_GPIO_Port                                     TP_GPIO_2_GPIO_Port

// Output: External SDA
#define TEST_MODE_CLOCK_OUTPUT_Pin                                    GPIO_PIN_7
#define TEST_MODE_CLOCK_OUTPUT_GPIO_Port                              GPIOB

// Input: External SCL
#define TEST_MODE_CLOCK_INPUT_Pin                                     GPIO_PIN_6
#define TEST_MODE_CLOCK_INPUT_GPIO_Port                               GPIOB

// I2C
#define ENABLE_I2C                                                    1
#define I2C_INTERNAL_UNIT                                             2
#define I2C_INTERNAL_TIMING                                           0x2000090E

#define EEPROM_PAGE_SIZE                                              16

#define LED_ERROR_Pin                                                 LED_RGB_R_Pin
#define LED_ERROR_GPIO_Port                                           LED_RGB_R_GPIO_Port

#define LED_ACT_Pin                                                   LED_RGB_B_Pin
#define LED_ACT_GPIO_Port                                             LED_RGB_B_GPIO_Port

// Enable Calibration Parameters
#define ENABLE_FACTORY_INFO                                           1
#define ENABLE_PARAMS                                                 1

#elif defined(SOLENOID_CONTROLLER)

#include "solenoid_controller.h"

// Boot Switch
#define BOOT_Pin                                                      SW_BOOTLOADER_Pin
#define BOOT_GPIO_Port                                                SW_BOOTLOADER_GPIO_Port
#define BOOT_PIN_ACTIVE_LOW                                           true

// Error LED
#define LED_ERROR_Pin                                                 LED_FAULT_Pin
#define LED_ERROR_GPIO_Port                                           LED_FAULT_GPIO_Port

// Test Mode
#define TEST_MODE_CLOCK_INPUT_Pin                                     TP_1_Pin
#define TEST_MODE_CLOCK_INPUT_GPIO_Port                               TP_1_GPIO_Port

#define TEST_MODE_ENTER_Pin                                           TEST_MODE_CLOCK_INPUT_Pin
#define TEST_MODE_ENTER_GPIO_Port                                     TEST_MODE_CLOCK_INPUT_GPIO_Port

// I2C
#define ENABLE_I2C                                                    1
#define I2C_INTERNAL_UNIT                                             1
#define I2C_INTERNAL_CLOCK                                            100000
#define I2C_INTERNAL_CLOCK_PERIPH                                     LL_APB1_GRP1_PERIPH_I2C1
#define I2C_INTERNAL_EV_IRQ                                           I2C1_EV_IRQn
#define I2C_INTERNAL_ER_IRQ                                           I2C1_ER_IRQn

// Enable Calibration Parameters
#define ENABLE_FACTORY_INFO                                           1
#define ENABLE_PARAMS                                                 1

#elif defined(STEPPER_CONTROLLER)

#include "stepper_controller.h"

// Boot pin (TP1 - PA13)
#define BOOT_Pin                                                      SW_BOOTLOADER_Pin
#define BOOT_GPIO_Port                                                SW_BOOTLOADER_GPIO_Port
#define BOOT_PIN_ACTIVE_LOW                                           true

// Error LED
#define LED_ERROR_Pin                                                 LED_FAULT_Pin
#define LED_ERROR_GPIO_Port                                           LED_FAULT_GPIO_Port

// Test Mode
#define TEST_MODE_ENTER_Pin                                           GPIO_PIN_12
#define TEST_MODE_ENTER_GPIO_Port                                     GPIOA

#define TEST_MODE_CLOCK_INPUT_Pin                                     PWM_OUT_A_Pin
#define TEST_MODE_CLOCK_INPUT_GPIO_Port                               PWM_OUT_GPIO_Port
#define TEST_MODE_CLOCK_OUTPUT_Pin                                    PWM_OUT_B_Pin
#define TEST_MODE_CLOCK_OUTPUT_GPIO_Port                              PWM_OUT_GPIO_Port

// I2C
#define ENABLE_I2C                                                    1
#define I2C_INTERNAL_UNIT                                             1
#define I2C_INTERNAL_CLOCK                                            100000
#define I2C_INTERNAL_CLOCK_PERIPH                                     LL_APB1_GRP1_PERIPH_I2C1
#define I2C_INTERNAL_EV_IRQ                                           I2C1_EV_IRQn
#define I2C_INTERNAL_ER_IRQ                                           I2C1_ER_IRQn

// Enable Calibration Parameters
#define ENABLE_FACTORY_INFO                                           1
#define ENABLE_PARAMS                                                 1

#elif defined(UNIVERSAL_TEST_FIXTURE)

#include "universal_test_fixture.h"

// Boot pin (GPIO_3)
#define BOOT_Pin                                                      GPIO_PIN_4
#define BOOT_GPIO_Port                                                GPIOB
#define BOOT_PIN_ACTIVE_LOW                                           true

#define CAN_UNIT                                                      1

// Test Mode (GPIO_0)
#define TEST_MODE_ENTER_Pin                                           GPIO_PIN_0
#define TEST_MODE_ENTER_GPIO_Port                                     GPIOC

// (GPIO_1)
#define TEST_MODE_CLOCK_INPUT_Pin                                     GPIO_PIN_1
#define TEST_MODE_CLOCK_INPUT_GPIO_Port                               GPIOC

// (GPIO_2)
#define TEST_MODE_CLOCK_OUTPUT_Pin                                    GPIO_PIN_5
#define TEST_MODE_CLOCK_OUTPUT_GPIO_Port                              GPIOB

// I2C
#define ENABLE_I2C                                                    1
#define I2C_INTERNAL_UNIT                                             2
#define I2C_INTERNAL_CLOCK                                            100000
#define I2C_INTERNAL_CLOCK_PERIPH                                     LL_APB1_GRP1_PERIPH_I2C2
#define I2C_INTERNAL_SDA_SET_AFPIN                                    LL_GPIO_SetAFPin_0_7
#define I2C_INTERNAL_SCL_SET_AFPIN                                    LL_GPIO_SetAFPin_8_15
#define I2C_INTERNAL_EV_IRQ                                           I2C2_EV_IRQn
#define I2C_INTERNAL_ER_IRQ                                           I2C2_ER_IRQn

// Enable Calibration Parameters
#define ENABLE_FACTORY_INFO                                           1
#define ENABLE_PARAMS                                                 1

#else

#include <stm32_util.h>

typedef struct __attribute__ ((aligned(4))) {
  factory_info_header_t header;
} factory_info_t;

#define DEVICE_TYPE                                                   0

// Generic bootloaders
#if defined(STM32F042x6)

#define APP_NAME                                                      "io.p-systems.bootloader.f042x6"

#elif defined(STM32F072xB)

#define APP_NAME                                                      "io.p-systems.bootloader.f072xB"

// Boot pin
#define BOOT_Pin                                                      GPIO_PIN_7
#define BOOT_GPIO_Port                                                GPIOB
#define BOOT_PIN_ACTIVE_LOW                                           false

// Status LED
#define LED_ERROR_Pin                                                 GPIO_PIN_10
#define LED_ERROR_GPIO_Port                                           GPIOA

// CAN terminate pin
#define CAN_TERM_Pin                                                  GPIO_PIN_4
#define CAN_TERM_GPIO_Port                                            GPIOB

#define STATUS_LED_ON                                                 GPIO_PIN_RESET
#define STATUS_LED_OFF                                                GPIO_PIN_SET

#elif defined(STM32F302x8)

#define APP_NAME                                                      "io.p-systems.bootloader.f302x8"

#elif defined(STM32F413xx)

#define APP_NAME                                                      "io.p-systems.bootloader.f413xx"
#define CAN                                                           CAN1
#define CAN_UNIT                                                      1

#endif

#endif

/**
 * Platform specific settings
 */
#if defined(STM32F042x6)

// Location of system bootloader is architecture specific
#define SYSTEM_BOOTLOADER_ADDRESS                                     0x1FFFC400

#ifndef FLASH_PAGE_SIZE
#define FLASH_PAGE_SIZE                                               0x400U
#endif

#elif defined(STM32F072xB)

// Location of system bootloader is architecture specific
#define SYSTEM_BOOTLOADER_ADDRESS                                     0x1FFFC800

#ifndef FLASH_PAGE_SIZE
#define FLASH_PAGE_SIZE                                               0x800U
#endif

#elif defined(STM32F302x8)

// Location of system bootloader is architecture specific
#define SYSTEM_BOOTLOADER_ADDRESS                                     0x1FFFD800

#define CAN_PIN_SPEED                                                 GPIO_SPEED_FREQ_HIGH
#define I2C_PIN_SPEED                                                 GPIO_SPEED_FREQ_HIGH
#define CAN_FILTER_IF                                                 CAN

#elif defined(STM32F413xx)

#define CAN_PIN_SPEED                                                 GPIO_SPEED_FREQ_VERY_HIGH
#define I2C_PIN_SPEED                                                 GPIO_SPEED_FREQ_VERY_HIGH

// CAN2 filters are (for some fucking reason) set through CAN1 so if using CAN2...
#ifndef CAN_FILTER_IF
#define CAN_FILTER_IF                                                 CAN1
#endif

#endif

#ifndef FIRMWARE_BASE_ADDRESS
#define FIRMWARE_BASE_ADDRESS                                         0x08004000
#endif

#ifndef HARDWARE_VERSION_MAJOR
#define HARDWARE_VERSION_MAJOR                                        0
#endif

#ifndef HARDWARE_VERSION_MINOR
#define HARDWARE_VERSION_MINOR                                        0
#endif

// Hardware Features
#ifndef ENABLE_I2C
#define ENABLE_I2C                                                    0
#endif

// Software Features
// (Note: turn these on/off in make file or hardware specific define)
#ifndef ENABLE_APP_DESCRIPTOR
#define ENABLE_APP_DESCRIPTOR                                         1
#endif

#ifndef ENABLE_AUTO_BAUD
#define ENABLE_AUTO_BAUD                                              1
#endif

#ifndef ENABLE_DYNAMIC_ID_ALLOCATION
#define ENABLE_DYNAMIC_ID_ALLOCATION                                  1
#endif

#ifndef ENABLE_FACTORY_INFO
#define ENABLE_FACTORY_INFO                                           1
#endif

#ifndef ENABLE_IMAGE_VERIFY
#define ENABLE_IMAGE_VERIFY                                           1
#endif

#ifndef ENABLE_OPTION_BYTE_WRITE
#define ENABLE_OPTION_BYTE_WRITE                                      1
#endif

#ifndef ENABLE_PARAMS
#define ENABLE_PARAMS                                                 0
#endif

#ifndef ENABLE_TRANSPORT_STATS
#define ENABLE_TRANSPORT_STATS                                        1
#endif

/**
 * Subroutines
 */

/**
 * @brief Start bootloader
 */
void Run_Bootloader();

#endif // P_SYSTEMS_BOOTLOADER_BOOTLOADER_H
