/**
 *
 * Author: Stou Sandalski <stou@p-systems.io>
 * Copyright (c) 2021 - Pomegranate Systems LLC
 *
 * License: MIT and 3-Clause BSD (See LICENSE.md)
 *
 */

#ifndef P_SYSTEMS_BOOTLOADER_MAIN_H
#define P_SYSTEMS_BOOTLOADER_MAIN_H

#include <stdbool.h>

#if defined(STM32F0)

#elif  defined(STM32F3)

#include <stm32f3xx_ll_bus.h>
#include "stm32f3xx_ll_cortex.h"
#include "stm32f3xx_ll_exti.h"
#include "stm32f3xx_ll_gpio.h"
#include "stm32f3xx_ll_i2c.h"
#include "stm32f3xx_ll_tim.h"
#include <stm32f3xx_ll_rcc.h>
#include "stm32f3xx_ll_system.h"
#include <stm32f3xx_ll_tim.h>
#include "stm32f3xx_ll_utils.h"

#elif  defined(STM32F4)

#include <stm32f4xx_ll_bus.h>
#include "stm32f4xx_ll_cortex.h"
#include <stm32f4xx_ll_gpio.h>
#include <stm32f4xx_ll_i2c.h>
#include "stm32f4xx_ll_pwr.h"
#include <stm32f4xx_ll_rcc.h>
#include "stm32f4xx_ll_system.h"
#include <stm32f4xx_ll_tim.h>
#include "stm32f4xx_ll_utils.h"

#endif

/**
 * @brief De-initialize all the hardware and peripherals in preparation for jumping
 * into the application code.
 *
 */
void Hardware_DeInit();

bool Verify_Application_Image(const uint32_t base_address);

#endif // P_SYSTEMS_BOOTLOADER_MAIN_H
