/**
 *
 * Author: Stou Sandalski <stou@p-systems.io>
 * Copyright (c) 2021 - Pomegranate Systems LLC
 *
 * License: MIT and 3-Clause BSD (See LICENSE.md)
 *
 */

#ifndef P_SYSTEMS_BOOTLOADER_NODE_H
#define P_SYSTEMS_BOOTLOADER_NODE_H

#include <stm32_util.h>

/**
 * @brief Bring up the CAN interface
 */
bool CANbus_Init();

/**
 * @brief Process messages in the request queue
 */
void Service_Requests();

/**
 *  @brief Request file contents for firmware upgrades
 */
void Start_File_Read();

#endif // P_SYSTEMS_BOOTLOADER_NODE_H
