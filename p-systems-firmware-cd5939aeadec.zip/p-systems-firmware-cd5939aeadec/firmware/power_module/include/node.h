/**
 *
 * Author: Stou Sandalski <stou@p-systems.io>
 * Copyright (c) 2021 - Pomegranate Systems LLC
 *
 * License: MIT and 3-Clause BSD (See LICENSE.md)
 *
 */

#ifndef P_SYSTEMS_POWER_MODULE_NODE_H
#define P_SYSTEMS_POWER_MODULE_NODE_H

#include <stm32_util.h>

/**
 * Bring-up CANbus interface (including autobaud and uavcan id)
 */
bool CANbus_Init();

/**
 * Process UAVCAN requests
 */
void Service_Requests();

#endif // P_SYSTEMS_POWER_MODULE_NODE_H
