/**
 *
 * Author: Stou Sandalski <stou@p-systems.io>
 * Copyright (c) 2021 - Pomegranate Systems LLC
 *
 * License: MIT and 3-Clause BSD (See LICENSE.md)
 *
 */

#include "params.h"

#include <stddef.h>
#include <stdint.h>

#include <stm32_util.h>
#include <uavcan_v0.h>

#include "main.h"
#include "power_module.h"

extern factory_info_t factory_info;
extern power_module_parameters_t parameters;

static const parameter_info_t parameter_info_table[] = {

    ADD_PARAM_INT(BATTERY_ID,
                  power_module_parameters_t, battery_id, 0),
    ADD_PARAM_INT(BATTERY_INSTANCE_ID,
                  power_module_parameters_t, battery_instance_id, 0),
    ADD_PARAM_INT(BATTERY_CAPACITY,
                  power_module_parameters_t, battery_capacity_mAh, 0),
    ADD_PARAM_REAL(BATTERY_V_EMPTY,
                   power_module_parameters_t, battery_v_empty, 0),
    ADD_PARAM_REAL(BATTERY_V_FULL,
                   power_module_parameters_t, battery_v_full, 0),
    ADD_PARAM_REAL(BATTERY_CURRENT_LIMIT_MAX,
                   power_module_parameters_t, bus_main_current_limit_max, 0),
    ADD_PARAM_REAL(BATTERY_VOLTAGE_LIMIT_MIN,
                   power_module_parameters_t, bus_main_voltage_limit_min, 0),
    ADD_PARAM_REAL(BATTERY_VOLTAGE_LIMIT_MAX,
                   power_module_parameters_t, bus_main_voltage_limit_max, 0),
    ADD_PARAM_INT(BATTERY_STATUS_MSG_INTERVAL_MS,
                  power_module_parameters_t, battery_status_msg_interval_ms, 0),

    ADD_PARAM_BOOL(SYSTEM_ENABLE_CURRENT_TRACK,
                   power_module_parameters_t, bus_main_enable_current_integration, 0),
    ADD_PARAM_BOOL(SYSTEM_AUTO_DISABLE_CURRENT_TRACK,
                   power_module_parameters_t, bus_main_auto_disable_current_track, 0),

    ADD_PARAM_BOOL(CAN_ENABLE_TERM,
                   power_module_parameters_t, can.bus_termination_enable, 0),
    ADD_PARAM_INT(CAN_DEFAULT_BAUD_KBPS,
                  power_module_parameters_t, can.default_baud_kbps, 0),
    ADD_PARAM_BOOL(CAN_ENABLE_AUTO_BAUD,
                   power_module_parameters_t, can.auto_baud_enable, 0),
    ADD_PARAM_INT(CAN_AUTO_BAUD_RETRY_TIMEOUT_MS,
                  power_module_parameters_t, can.auto_baud_retry_time_ms, 0),
    ADD_PARAM_INT(CAN_AUTO_BAUD_MAX_RETRIES,
                  power_module_parameters_t, can.auto_baud_max_retries, 0),
    ADD_PARAM_INT(UAVCAN_DEFAULT_NODE_ID,
                  power_module_parameters_t, can.default_node_id, 0),
    ADD_PARAM_BOOL(UAVCAN_DYNAMIC_ID_ALLOCATION_ENABLE,
                   power_module_parameters_t, can.dynamic_id_allocation_enable, 0),
    ADD_PARAM_INT(UAVCAN_DYNAMIC_ID_ALLOCATION_RETRY_TIMEOUT_MS,
                  power_module_parameters_t, can.dynamic_id_allocation_retry_time_ms, 0),
    ADD_PARAM_INT(UAVCAN_DYNAMIC_ID_ALLOCATION_MAX_RETRIES,
                  power_module_parameters_t, can.dynamic_id_allocation_max_retries, 0),

    ADD_PARAM_INT(BUS_MAIN_CIRCUIT_ID,
                  power_module_parameters_t, bus_main_circuit_id, 0),
    ADD_PARAM_BOOL(BUS_MAIN_CURRENT_FILTER_ENABLE,
                   power_module_parameters_t, bus_main_enable_current_filter, 0),
    ADD_PARAM_REAL(BUS_MAIN_CURRENT_FILTER_CONST,
                   power_module_parameters_t, bus_main_filter_coefficient, 0),
    ADD_PARAM_INT(BUS_MAIN_RANGE_SWITCH_HIGH_MA,
                  power_module_parameters_t, bus_main_sensor_range_switch_high_mA, 0),
    ADD_PARAM_INT(BUS_MAIN_RANGE_SWITCH_LOW_MA,
                  power_module_parameters_t, bus_main_sensor_range_switch_low_mA, 0),
    ADD_PARAM_INT(BUS_MAIN_CIRCUIT_STATUS_MSG_INTERVAL_MS,
                  power_module_parameters_t, bus_main_circuit_status_msg_interval_ms, 0),
    ADD_PARAM_REAL(BUS_MAIN_R_SHUNT,
                   power_module_parameters_t, bus_main_R_shunt,
                   offsetof(factory_info_t, R_shunt_main)),

    ADD_PARAM_INT(BUS_AUX_CIRCUIT_ID,
                  power_module_parameters_t, bus_aux_circuit_id, 0),
    ADD_PARAM_REAL(BUS_AUX_R_SHUNT,
                   power_module_parameters_t, bus_aux_R_shunt,
                   offsetof(factory_info_t, R_shunt_aux)),

    ADD_PARAM_INT(BUS_AUX_CIRCUIT_STATUS_MSG_INTERVAL_MS,
                  power_module_parameters_t, bus_aux_circuit_status_msg_interval_ms, 0),
    ADD_PARAM_REAL(BUS_AUX_CURRENT_LIMIT_MAX,
                   power_module_parameters_t, bus_aux_current_limit_max, 0),
    ADD_PARAM_REAL(BUS_AUX_VOLTAGE_LIMIT_MIN,
                   power_module_parameters_t, bus_aux_voltage_limit_min, 0),
    ADD_PARAM_REAL(BUS_AUX_VOLTAGE_LIMIT_MAX,
                   power_module_parameters_t, bus_aux_voltage_limit_max, 0),

    ADD_PARAM_INT(BUS_SYS_CIRCUIT_ID,
                  power_module_parameters_t, bus_sys_circuit_id, 0),
    ADD_PARAM_INT(BUS_SYS_CIRCUIT_STATUS_MSG_INTERVAL_MS,
                  power_module_parameters_t, bus_sys_circuit_status_msg_interval_ms, 0),

    ADD_PARAM_INT(MCU_TEMP_DEVICE_ID,
                  power_module_parameters_t, mcu_temp_device_id, 0),
    ADD_PARAM_INT(MCU_TEMP_MSG_INTERVAL_MS,
                  power_module_parameters_t, mcu_temp_msg_interval_ms, 0),
    ADD_PARAM_REAL(MCU_TEMP_LIMIT_MAX_C,
                   power_module_parameters_t, mcu_temp_limit_max_C, 0),
    ADD_PARAM_REAL(MCU_TEMP_LIMIT_MIN_C,
                   power_module_parameters_t, mcu_temp_limit_min_C, 0),

    ADD_PARAM_INT(PCB_TEMP_DEVICE_ID,
                  power_module_parameters_t, pcb_temp_device_id, 0),
    ADD_PARAM_INT(PCB_TEMP_MSG_INTERVAL_MS,
                  power_module_parameters_t, pcb_temp_msg_interval_ms, 0),
    ADD_PARAM_REAL(PCB_TEMP_LIMIT_MAX_C,
                   power_module_parameters_t, pcb_temp_limit_max_C, 0),
    ADD_PARAM_REAL(PCB_TEMP_LIMIT_MIN_C,
                   power_module_parameters_t, pcb_temp_limit_min_C, 0),

    ADD_PARAM_BOOL(LED_ENABLED,
                   power_module_parameters_t, led_enabled, 0),
    ADD_PARAM_BOOL(LED_IDENTIFY,
                   power_module_parameters_t, led_enable_identify, 0),

    ADD_PARAM_INT(LED_BRIGHTNESS_SCALE_R,
                  power_module_parameters_t, led_brightness_scale[0],
                  offsetof(factory_info_t, led_brightness[0])),
    ADD_PARAM_INT(LED_BRIGHTNESS_SCALE_G,
                  power_module_parameters_t, led_brightness_scale[1],
                  offsetof(factory_info_t, led_brightness[1])),
    ADD_PARAM_INT(LED_BRIGHTNESS_SCALE_B,
                  power_module_parameters_t, led_brightness_scale[2],
                  offsetof(factory_info_t, led_brightness[2])),


    ADD_PARAM_BOOL(SYSTEM_ENABLE_EXTERNAL_I2C,
                   power_module_parameters_t, system_enable_external_i2c, 0),
    ADD_PARAM_BOOL(SYSTEM_ENABLE_FIRMWARE_UPDATES,
                   power_module_parameters_t, system_enable_firmware_updates, 0),
    ADD_PARAM_INT(SYSTEM_EMERGENCY_MSG_INTERVAL_MS,
                  power_module_parameters_t, system_emergency_msg_interval_ms, 0),
    ADD_PARAM_INT(SYSTEM_NODE_STATUS_MSG_INTERVAL_MS,
                  power_module_parameters_t, system_node_status_msg_interval_ms, 0),
    ADD_PARAM_INT(SYSTEM_SENSOR_READOUT_INTERVAL_MS,
                  power_module_parameters_t, system_sensor_readout_interval_ms, 0)
};

bool dirty_table[sizeof(parameter_info_table) / sizeof(parameter_info_t)];

/**
 * Parameter function
 */
bool Params_Call_Handle_GetSet(int node_id,
                               parameter_getset_t *param_get_set,
                               request_t request){

  return Params_Handle_GetSet(node_id,
                              sizeof(parameter_info_table) / sizeof(parameter_info_t),
                              parameter_info_table,
                              (uint8_t *) &factory_info,
                              dirty_table,
                              param_get_set,
                              request,
                              (uint8_t *) &parameters);
}

void Params_Load_Default_Values(){

  Params_Load_Defaults(sizeof(parameter_info_table) / sizeof(parameter_info_t),
                       parameter_info_table,
                       (uint8_t *) &factory_info,
                       dirty_table,
                       (uint8_t *) &parameters);

  // Set the LED to pure blue for some time to indicate a settings reset
  LED_Set_Values(0, 0, 255, LED_RESET_DEFAULT_ON_MS);
}

/**
 * Load the parameters from the eprom
 *
 * return true if parameters are loaded from eeprom and false if defaults were used
 */
bool Params_Load(){

  // Try to load
  if(Params_EEPROM_Load(I2C_INTERNAL,
                        EEPROM_ADDR_7B,
                        EEPROM_PARAM_HEADER_START_PAGE,
                        EEPROM_PARAM_START_PAGE,
                        PARAMETERS_CURRENT_VERSION,
                        sizeof(parameter_info_table) / sizeof(parameter_info_t),
                        parameter_info_table,
                        (uint8_t *) &factory_info,
                        dirty_table,
                        (uint8_t *) &parameters) > 0){

    // Some of the parameters changed during loading so save them
    Params_Save();
  }
  return true;
}

void Params_Save(){
  int parameter_count = sizeof(parameter_info_table) / sizeof(parameter_info_t);

  // Disable Write Protection
  LL_GPIO_ResetOutputPin(EEPROM_WP_GPIO_Port, EEPROM_WP_Pin);

  Params_EEPROM_Save(I2C_INTERNAL,
                     EEPROM_ADDR_7B,
                     EEPROM_PARAM_HEADER_START_PAGE,
                     EEPROM_PARAM_START_PAGE,
                     PARAMETERS_CURRENT_VERSION,
                     parameter_count,
                     parameter_info_table,
                     dirty_table,
                     (uint8_t *) &parameters);

  // Enable Write Protection
  LL_GPIO_SetOutputPin(EEPROM_WP_GPIO_Port, EEPROM_WP_Pin);
}
