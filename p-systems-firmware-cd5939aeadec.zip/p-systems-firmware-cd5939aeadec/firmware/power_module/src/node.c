/**
 *
 * Author: Stou Sandalski <stou@p-systems.io>
 * Copyright (c) 2021 - Pomegranate Systems LLC
 *
 * License: MIT and 3-Clause BSD (See LICENSE.md)
 *
 * Description: Handle "network traffic" from UAVCAN, etc.
 *
 */

#include "node.h"

#include <stddef.h>
#include <stdint.h>
#include <string.h>

#include <stm32_util.h>
#include <uavcan_v0.h>

#include "main.h"
#include "params.h"
#include "power_module.h"

/**
 * Globals
 */

extern factory_info_t factory_info;
extern boot_info_t boot_info;
extern node_info_t node;
extern power_module_parameters_t parameters;


/**
 * CANbus Filters
 */
uint32_t can_filters[][2] = {
    {UAVCAN_PROTOCOL_GET_NODE_INFO_FILTER_ID,              UAVCAN_PROTOCOL_GET_NODE_INFO_FILTER_MASK},
    {UAVCAN_PROTOCOL_GET_TRANSPORT_STATS_FILTER_ID,        UAVCAN_PROTOCOL_GET_TRANSPORT_STATS_FILTER_MASK},
    {UAVCAN_PROTOCOL_PARAM_FILTER_ID,                      UAVCAN_PROTOCOL_PARAM_FILTER_MASK},
    {UAVCAN_PROTOCOL_RESTART_NODE_FILTER_ID,               UAVCAN_PROTOCOL_RESTART_NODE_FILTER_MASK},
    {UAVCAN_PROTOCOL_FILE_BEGIN_FIRMWARE_UPDATE_FILTER_ID, UAVCAN_PROTOCOL_FILE_BEGIN_FIRMWARE_UPDATE_FILTER_MASK},
    {IO_P_SYSTEMS_DEVICE_I2C_FILTER_ID,                    IO_P_SYSTEMS_DEVICE_I2C_FILTER_MASK}
};

/**
 * Request Handling
 */

request_queue_t queue;

// Parameter handling
parameter_getset_t param_get_set;

// I2C
uint8_t i2c_buffer[IO_P_SYSTEMS_DEVICE_I2C_READ_MAX_SIZE];
uint8_t i2c_buffer_len;

uavcan_init_t uavcan_init;


/**
 * Initialize the can interface
 *
 * @return
 */
bool CANbus_Init(){

  uavcan_init.can_if = uavcan_init.can_filter_if = CAN;
  uavcan_init.can_filters = &can_filters[0][0];
  uavcan_init.filter_count = (sizeof(can_filters) / (2 * sizeof(uint32_t)));

  UAVCAN_Init(&boot_info, &node, &parameters.can, &uavcan_init);

  // Check if we left the auto_baud state
  if(node.can_status != CAN_STATUS_AUTO_BAUD){
    LED_Remove_State(LED_STATE_AUTO_BAUD);
  }

  return true;
}

void Service_Request_Param_GetSet(const char *name){
  // Perform any extra init work here
  if(strcmp(name, PARAM_NAME_CAN_ENABLE_TERM) == 0){
    CAN_Set_Termination();
  }else if((strcmp(name, PARAM_NAME_BUS_MAIN_R_SHUNT) == 0)
           || (strcmp(name, PARAM_NAME_BATTERY_CAPACITY) == 0)
           || (strcmp(name, PARAM_NAME_BUS_MAIN_CURRENT_FILTER_CONST) == 0)){
    Battery_Capacity_Calc();
  }else if(strcmp(name, PARAM_NAME_SYSTEM_ENABLE_EXTERNAL_I2C) == 0){

    if(parameters.system_enable_external_i2c){
      I2C_External_Init();
    }else{
      I2C_External_DeInit();
    }

  }else if((strcmp(name, PARAM_NAME_LED_ENABLED) == 0)){
    if(parameters.led_enabled){
      LED_Init();
    }else{
      LED_DeInit();
    }
  }else{
    // Otherwise update the globals
    Update_Globals();
  }
}

void Service_Request_Begin_Firmware_Update(request_t *request){

  // uavcan.protocol.file.BeginFirmwareUpdate
  if(parameters.system_enable_firmware_updates){

    // Bootloader handles response message
    boot_info.signature = BOOT_INFO_SIGNATURE;
    boot_info.enable_term = parameters.can.bus_termination_enable;
    boot_info.node_id = node.id;
    boot_info.update_req_node_id = request->node_id;
    boot_info.update_req_priority = request->priority;
    boot_info.update_req_transfer_id = request->transfer_id;
    boot_info.crc = CRC_16_Compute(0xFFFFU, &boot_info, sizeof(boot_info_t));

    // De-Init Hardware
    CAN_DeInit();

    I2C_Internal_DeInit();

    if(parameters.system_enable_external_i2c){
      I2C_External_DeInit();
    }

    TIM_DeInit();

    ADC_DeInit();

    GPIO_DeInit();

    SystemClock_DeInit();

    // If the magic is not present we are on a 1.x bootloader
    if(factory_info.header.magic == FACTORY_INFO_MAGIC){
      __disable_irq();
    }

    LL_FLASH_DisablePrefetch();

    // Jump to bootloader
    Bootloader_Jump(FLASH_BASE);
  }else{
    Send_BeginFirmwareUpdate_Response(node.id,
                                      *request,
                                      UAVCAN_PROTOCOL_FILE_BEGIN_FIRMWARE_UPDATE_ERROR_INVALID_MODE,
                                      "Only the bootloader can update firmware.");
  }
}

/**
 *
 * @param data_type_id
 * @param is_service
 * @param source_node_id
 * @param priority
 * @param transfer_id
 * @param payload
 * @param payload_len
 */
void UAVCAN_Handle_Message(const uint16_t data_type_id,
                           const bool is_service,
                           const uint8_t source_node_id,
                           const uint8_t priority,
                           uint8_t transfer_id,
                           uint8_t *payload,
                           uint32_t payload_len){

  size_t firmware_file_path_len;

  // Dispatch data
  switch(data_type_id){

    case 1: // UAVCAN_PROTOCOL_NODE_ID_ALLOCATION_ID and UAVCAN_PROTOCOL_GET_NODE_INFO_ID

      // If we have no name this message is actually dynamic id resolution
      if(!node.id_valid){
        // uavcan.protocol.dynamic_id.Allocation

        // Need to see if this message is meant for this node
        // by checking how many UUID bytes match
        int uuid_matches = 0;
        for(int i = 0; i < payload_len - 1; ++i){
          if(payload[1 + uuid_matches] != node.uuid[uuid_matches]){
            break;
          }
          ++uuid_matches;
        }

        // Decode message
        if(uuid_matches == 6){
          // Message 2
          Send_Node_ID_Allocation_Request(&node.uuid[6], 6, 0, false);
        }else if(uuid_matches == 12){
          // Message 3
          Send_Node_ID_Allocation_Request(&node.uuid[12], 4, 0, false);
        }else if(uuid_matches == 16){
          node.id = (payload[0] >> 1U);
          node.id_valid = true;
        }else{
          // Something is wrong so reset back to start
          uavcan_init.dynamic_id_allocation_timestamp = 0;
        }
      }else{
        Request_Queue_Add(&queue,
                          data_type_id,
                          source_node_id,
                          transfer_id,
                          priority,
                          0);
      }
      break;

    case UAVCAN_PROTOCOL_NODE_STATUS_ID:
      uavcan_init.node_status_received = true;
      break;

    case UAVCAN_PROTOCOL_GET_TRANSPORT_STATS_ID:
      // uavcan.protocol.GetTransportStats / uavcan.protocol.GlobalTimeSync

      if(is_service){
        Request_Queue_Add(&queue,
                          data_type_id,
                          source_node_id,
                          transfer_id,
                          priority,
                          0);
      }
      break;

    case UAVCAN_PROTOCOL_RESTART_NODE_ID:
      // uavcan.protocol.RestartNode

      if(Check_NodeRestart_Request(payload, payload_len)){
        Request_Queue_Add(&queue,
                          data_type_id,
                          source_node_id,
                          transfer_id,
                          priority,
                          0);
      }
      break;

    case UAVCAN_PROTOCOL_FILE_BEGIN_FIRMWARE_UPDATE_ID:
      // uavcan.protocol.file.BeginFirmwareUpdate

      Deserialize_BeginFirmwareUpdate_Request(payload,
                                              payload_len,
                                              &boot_info.server_node_id,
                                              &firmware_file_path_len,
                                              (char *) boot_info.firmware_file_path);

      if(boot_info.server_node_id == 0){
        boot_info.server_node_id = source_node_id;
      }
      boot_info.firmware_file_path_len = firmware_file_path_len;

      Request_Queue_Add_Unique(&queue,
                               data_type_id,
                               source_node_id,
                               transfer_id,
                               priority,
                               0);

      break;

    case UAVCAN_PROTOCOL_PARAM_EXECUTE_OPCODE_ID:
      // uavcan.protocol.param.ExecuteOpcode

      // First byte is the opcode, the rest is a reserved future parameter...
      Request_Queue_Add_Unique(&queue,
                               data_type_id,
                               source_node_id,
                               transfer_id,
                               priority,
                               payload[0]);

      break;

    case UAVCAN_PROTOCOL_PARAM_GET_SET_ID:
      // uavcan.protocol.param.GetSet

      Request_Queue_Add_Unique(&queue,
                               data_type_id,
                               source_node_id,
                               transfer_id,
                               priority,
                               0);

      Deserialize_GetSet_Request(payload,
                                 payload_len,
                                 &param_get_set);
      break;

    case IO_P_SYSTEMS_DEVICE_I2C_WRITE_ID:
      // io.psystems.i2c.Write

    case IO_P_SYSTEMS_DEVICE_I2C_READ_ID:
      // io.psystems.i2c.Read/.Write

      // Save the payload so it can be written
      memcpy(i2c_buffer, payload, MIN(IO_P_SYSTEMS_DEVICE_I2C_READ_MAX_SIZE, payload_len));
      i2c_buffer_len = (uint8_t) payload_len;

      if(parameters.system_enable_external_i2c){
        Request_Queue_Add_Unique(&queue,
                                 data_type_id,
                                 source_node_id,
                                 transfer_id,
                                 priority,
                                 0);
      }
      break;

    default:
      // TODO: Flag unknown message?
      break;
  }
}

void Service_Requests(){

  bool param_ok = false;

  // If there are no requests pending, return
  if(!queue.request[queue.top].pending){
    return;
  }

  // Dispatch message
  switch(queue.request[queue.top].type_id){

    case UAVCAN_PROTOCOL_FILE_BEGIN_FIRMWARE_UPDATE_ID:
      // uavcan.protocol.file.BeginFirmwareUpdate
      Service_Request_Begin_Firmware_Update(&queue.request[queue.top]);
      break;

    case UAVCAN_PROTOCOL_GET_NODE_INFO_ID:
      // uavcan.protocol.GetNodeInfo
      Send_GetNodeInfo_Response(&node, queue.request[queue.top]);
      break;

    case UAVCAN_PROTOCOL_GET_TRANSPORT_STATS_ID:
      // uavcan.protocol.GetTransportStat

      Send_GetTransportStats_Response(&node, queue.request[queue.top]);
      break;

    case UAVCAN_PROTOCOL_PARAM_EXECUTE_OPCODE_ID:
      // uavcan.protocol.param.ExecuteOpcode

      switch(queue.request[queue.top].data){

        case UAVCAN_PROTOCOL_PARAM_OPCODE_ERASE:
          // Load defaults and fall-through to save
          Params_Load_Default_Values(&parameters);

        case UAVCAN_PROTOCOL_PARAM_OPCODE_SAVE:
          Params_Save(&parameters);
          param_ok = true;
          break;

        default:
          param_ok = false;
          break;
      }
      Send_ExecuteOpcode_Response(node.id, queue.request[queue.top], 0, param_ok);
      break;

    case UAVCAN_PROTOCOL_PARAM_GET_SET_ID:
      // uavcan.protocol.param.GetSet

      if(Params_Call_Handle_GetSet(node.id,
                                   &param_get_set,
                                   queue.request[queue.top])){
        Service_Request_Param_GetSet(param_get_set.name);
      }

      break;

    case UAVCAN_PROTOCOL_RESTART_NODE_ID:
      // uavcan.protocol.RestartNode
      Send_NodeRestart_Response(node.id,
                                true,
                                queue.request[queue.top]);
      Busy_Wait(10);
      NVIC_SystemReset();

    case IO_P_SYSTEMS_DEVICE_I2C_READ_ID:
      // io.p-systems.i2c.Read
      Handle_I2C_Read_Request(node.id,
                              queue.request[queue.top],
                              I2C_EXTERNAL,
                              i2c_buffer[2],
                              i2c_buffer[3],
                              i2c_buffer[1]);
      break;

    case IO_P_SYSTEMS_DEVICE_I2C_WRITE_ID:
      // io.p-systems.i2c.Write
      Handle_I2C_Write_Request(node.id,
                               queue.request[queue.top],
                               I2C_EXTERNAL,
                               i2c_buffer[1],
                               i2c_buffer[2],
                               &i2c_buffer[3],
                               i2c_buffer_len - 3);
      break;
  }

  // Update queue pointers
  Request_Queue_Pop(&queue);
}
