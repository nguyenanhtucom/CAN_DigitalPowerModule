/**
 * Created: 29 Nov 2018
 * Author: Stou Sandalski <stou@icapsid.net>
 *
 * Description: stm32 interface to mcp9808
 *
 */

#include <stdbool.h>

#include "mcp9808.h"
#include <stm32_util.h>


/**
 * Read out the temperature of the MCP9808 with the given index, 0 is local, 1 is remote
 * @return
 */
float MCP9808_Readout(I2C_TypeDef *i2c,
                      uint8_t address_7_bit){
  uint8_t buffer[2];

  I2C_Read_Register(i2c,
                    address_7_bit,
                    MCP9808_REGISTER_T,
                    sizeof(buffer),
                    buffer);

  buffer[0] &= 0x1F;

  if(buffer[0] & 0x10){
    buffer[0] &= 0x0F;
    return 256 - (buffer[0] * 16.0f + buffer[1] / 16.0f);
  }else{
    return (buffer[0] * 16.0f + buffer[1] / 16.0f);
  }
}


#if 0
int16_t get_temperature(I2C_TypeDef* hi2c1,
                        uint8_t address_offset){

  uint8_t buffer[2];

  //
  buffer[0] = MCP9808_REGISTER_T;

  // first set the register pointer to the register wanted to be read
  HAL_I2C_Master_Transmit(hi2c1,
                          (MCP9808_BASE_ADDRESS | address_offset) << 1,
                          buffer, 1, 100);

  // receive the 2 x 8bit data into the receive buffer
  HAL_I2C_Master_Receive(hi2c1,
                         (MCP9808_BASE_ADDRESS | address_offset) << 1,
                         buffer, 2, 100);


  return 0;
}

void set_resolution(I2C_TypeDef* hi2c1,
                    uint8_t address_offset,
                    uint8_t resolution){
  uint8_t buffer[2];

  //
  buffer[0] = MCP9808_REGISTER_T;
  buffer[1] = resolution;

  // first set the register pointer to the register wanted to be read
  HAL_I2C_Master_Transmit(hi2c1,
                          (MCP9808_BASE_ADDRESS | address_offset) << 1,
                          buffer, 1, 100);

}


bool MCP9808_Check(I2C_TypeDef *hi2c,
                   uint16_t address){
  uint8_t buffer[2];
  uint8_t address_7bit = (uint8_t) (address << 1);

  buffer[0] = MCP9808_REGISTER_MANUFACTURER_ID;
  HAL_I2C_Master_Transmit(hi2c, address_7bit, buffer, 1, 100);
  HAL_I2C_Master_Receive(hi2c, address_7bit, buffer, 2, 100);

  return (buffer[1] == MCP9808_MANUFACTURER_ID);
}
#endif