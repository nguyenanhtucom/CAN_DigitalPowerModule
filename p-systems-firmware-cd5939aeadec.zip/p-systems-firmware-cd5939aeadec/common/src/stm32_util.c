/**
 *
 * Created On: 27 September 2019
 * Copyright (c) 2021 - Pomegranate Systems LLC
 *
 * Portions of this code are:
 *
 * Copyright (c) 2019 STMicroelectronics
 * Copyright (c) 2017 UAVCAN Team
 *
 * License: MIT and 3-Clause BSD (See LICENSE.md)
 *
 */

#include "stm32_util.h"

#include <string.h>
#include <stdint.h>

/**
 * Hardware Specific Headers and Hacks
 */
#if defined(STM32F0)

#include "stm32f0xx_ll_gpio.h"
#include "stm32f0xx_ll_i2c.h"
#include "stm32f0xx_ll_rcc.h"

#elif defined(STM32F3)

#include "stm32f3xx_ll_i2c.h"
//#include "stm32f3xx_ll_rcc.h"
#include "stm32f3xx_hal_flash.h"

#elif defined(STM32F4)

#include "stm32f4xx_ll_i2c.h"
#include "stm32f4xx_ll_rcc.h"

#define GPIO_NUMBER           16U

#else

#endif

#if !defined(EEPROM_PAGE_SIZE)
#define EEPROM_PAGE_SIZE                                              16
#endif


extern uint32_t System_Tick;

#if ENABLE_TRANSPORT_STATS
iface_stats_t interface_stats[CAN_IFACE_COUNT] = {};
#endif

/**
 * Low Level Data Manipulation Routines
 */

/**
 * @param b
 * @return
 */
float compute_average(rolling_buffer_t b){

  float total = 0;

  for(int i = 0; i < b.count; ++i){
    total += (float) b.data[i];
  }

  if(b.count == 0){
    return 0;
  }else{
    return total / (float) b.count;
  }
}

void rolling_buffer_inc(rolling_buffer_t *b){

  ++b->index;

  if(b->index >= ROLLING_BUFFER_MAX_SIZE){
    b->index = 0;
  }

  if(b->count < ROLLING_BUFFER_MAX_SIZE){
    ++b->count;
  }
}


void Busy_Wait(uint32_t delay_ms){
  uint32_t tickstart = System_Tick;

  delay_ms = MAX(1, delay_ms);

  while((System_Tick - tickstart) < delay_ms){
    __asm__ volatile("nop");
  }
}

/*
 * CRC functions
 */

uint16_t CRC_16_Add_Byte(uint16_t crc_val,
                         uint8_t byte){

  crc_val ^= (uint16_t) ((uint16_t) (byte) << 8U);

  for(uint8_t j = 0; j < 8; j++){
    crc_val = (crc_val & 0x8000U) ? (crc_val << 1U) ^ 0x1021U : crc_val << 1U;
  }

  return crc_val;
}

uint16_t CRC_16_Add_Signature(uint16_t crc,
                              uint64_t data_type_signature){

  for(size_t i = 0; i < 8; ++i){
    crc = CRC_16_Add_Byte(crc, (uint8_t) data_type_signature);
    data_type_signature = data_type_signature >> 8;
  }

  return crc;
}

uint16_t CRC_16_Compute(uint16_t crc,
                        const void *ptr,
                        size_t count){

  const uint8_t *buffer = ptr;

  for(int i = 0; i < count; ++i){
    crc = CRC_16_Add_Byte(crc, *(buffer + i));
  }

  return crc;
}


/**
 * http://reveng.sourceforge.net/crc-catalogue/17plus.htm#crc.cat.crc-64-we
 *
 * Compute CRC-64 using table
 *
 * @param table
 * @param crc
 * @param length
 * @param data
 *
 * @return
 */

uint64_t CRC_64_Compute(const uint64_t *table,
                        uint64_t crc,
                        size_t length,
                        const uint8_t *data){

  for(int i = 0; i < length; ++i){
    crc ^= ((0xFFU & (uint64_t) data[i]) << 56);
    uint8_t ix = 0xFFU & (crc >> 56);

    crc <<= 8;
    crc ^= table[ix];
  }

  return crc;
}

/**
 * Generate Table for the given CRC-64 Polynomial. Table has 256 entries.
 *
 * Tested and compared to:
 *
 *  http://www.sunshine2k.de/coding/javascript/crc/crc_js.html
 *
 * @param polynomial
 * @param output_table
 */
void CRC_64_Generate_Table(uint64_t polynomial,
                           uint64_t *output_table){

  for(int i = 0; i < 256; ++i){

    uint64_t crc = ((uint64_t) i) << 56;

    for(int j = 0; j < 8; ++j){
      crc = (crc & 0x8000000000000000) ? (crc << 1) ^ polynomial : crc << 1;
    }
    output_table[i] = crc;
  }
}

/**
 * Initialize a node_info_t structure
 *
 *
 *
 * @param node
 * @param default_node_id
 * @param version_major
 * @param version_minor
 * @param app_name
 */
void Node_Init(node_info_t *node,
               uint8_t health,
               uint8_t mode,
               uint8_t default_node_id,
               uint8_t sw_ver_major,
               uint8_t sw_ver_minor,
               uint32_t vcs_commit,
               uint64_t image_crc,
               const char *app_name,
               factory_info_header_t *factory_info){

  // Initialize node data
  memset(node, 0, sizeof(node_info_t));

  node->health = health;
  node->mode = mode;
  node->id = default_node_id;
  node->sw_version_major = sw_ver_major;
  node->sw_version_minor = sw_ver_minor;
  strncpy((char *) node->app_name, app_name, strlen(app_name));

  uint8_t device_type = 0;

  // Simple hash for basic random number generation
  const uint8_t p1 = 7;
  const uint8_t p2 = 31;
  node->hardware_hash = p1;

  // Load stm32 UUID
#if defined(STM32F0) || defined(STM32F3)
  // For F0: Section 33.1 of STM32F0 Reference Manual RM0091 (Page 925)
  volatile uint32_t *stm32_uuid = ((uint32_t *) 0x1FFFF7AC);
#elif defined(STM32F4)
  // Chapter 35 of STM32F413/423 Reference Manual RM0430 (Page 1315)
  volatile uint32_t *stm32_uuid = ((uint32_t *) 0x1FFF7A10);
#endif

  for(int j = 0; j < 3; ++j){

    uint32_t uuid_seg = stm32_uuid[j];

    for(int i = 0; i < 4; ++i){
      node->uuid[4 * j + i] = (uint8_t) (0xFFU & (uint8_t) uuid_seg);
      uuid_seg = uuid_seg >> 8U;

      node->hardware_hash = node->hardware_hash * p2 + node->uuid[4 * j + i];
    }
  }

  // Load the hardware version from the option bytes if available
#if defined(STM32F3)
  uint32_t ob_data = *(__IO uint32_t *) OB_DATA_ADDRESS_DATA0;

  device_type = 0xFF & ob_data;
  uint8_t version_major = 0x1F & (ob_data >> 16);
  uint8_t version_minor = 0x7 & (ob_data >> 21);

  node->hw_version_major = version_major;
  node->hw_version_minor = version_minor;
#else

#if defined(HARDWARE_VERSION_MAJOR)
  node->hw_version_major = HARDWARE_VERSION_MAJOR;
#endif
#if defined(HARDWARE_VERSION_MINOR)
  node->hw_version_minor = HARDWARE_VERSION_MINOR;
#endif

#endif

  // If factory info is valid use it to set the hardware version
  if(factory_info->magic == FACTORY_INFO_MAGIC){
//    node->hw_version_major = factory_info->device_version_major;
//    node->hw_version_minor = factory_info->device_version_minor;
    device_type = factory_info->device_type;
  }

  // Add more to the UUID
  node->uuid[13] = node->hw_version_minor;
  node->uuid[14] = node->hw_version_major;
  node->uuid[15] = device_type;

  // If default node ID is 0 it is set to the low 6 bits of the hardware hash
  if(default_node_id == 0){
    node->id = (uint8_t) (0x3F & node->hardware_hash);
  }

  // Interface stats
  node->image_crc = image_crc;
  node->vcs_commit = vcs_commit;

#if 0
  // Copy over the hardware certificate (it will be blank if it's invalid)
  for(int i = 0; i < MIN(sizeof(factory_info->crypto_hash), UAVCAN_HW_CERT_LENGTH_BYTES); ++i){
    node->hw_cert[i] = factory_info->crypto_hash[i];
  }
#endif
}

/**
 * Hardware Functions
 */

/**
 * bxCAN
 *
 */


uint32_t bxCAN_Get_Prescalar_8(uint32_t speed_kbs){

  switch(speed_kbs){

    case 1000:
      return 1;

    case 500:
      return 2;

    case 250:
      return 4;

    case 125:
      return 8;

    case 20:
      return 50;

    case 10:
      return 100;

    default:
      return 0;
  }
}

uint32_t bxCAN_Get_Prescalar_16(uint32_t speed_kbs){

  switch(speed_kbs){

    case 1000:
      return 1;

    case 500:
      return 2;

    case 250:
      return 4;

    case 125:
      return 8;

    case 100:
      return 10;

    case 50:
      return 20;

    case 20:
      return 50;

    case 10:
      return 100;

    default:
      return 0;
  }
}

uint32_t bxCAN_Get_Prescalar_48(uint32_t speed_kbs){

  switch(speed_kbs){

    case 1000:
      return 3;

    case 500:
      return 6;

    case 250:
      return 12;

    case 125:
      return 24;

    case 100:
      return 30;

    case 50:
      return 60;

    case 20:
      return 150;

    case 10:
      return 300;

    default:
      return 0;
  }
}

/**
 *
 * If using 8, 16, 48Mhz
 *
 * From: http://www.bittiming.can-wiki.info/
 *
 * @param speed_kbs
 * @param prescaler
 * @param seg
 */
uint32_t bxCAN_Get_Prescalar(uint32_t speed_kbs){

#if CANBUS_PRESCALAR == CANBUS_PRESCALAR_8MHZ
  return bxCAN_Get_Prescalar_8(speed_kbs);
#elif CANBUS_PRESCALAR == CANBUS_PRESCALAR_16MHZ
  return bxCAN_Get_Prescalar_16(speed_kbs);
#elif CANBUS_PRESCALAR == CANBUS_PRESCALAR_48MHZ
  return bxCAN_Get_Prescalar_48(speed_kbs);
#else
  return 0;
#endif
}

/**
 *
 *
 * @param can
 * @return
 */
bool bxCAN_Init(CAN_TypeDef *can,
                uint32_t baud_kbps,
                uint32_t timeout){

  uint32_t prescaler = bxCAN_Get_Prescalar(baud_kbps);
  uint32_t tickstamp;

  // Automatic Bus-Off Management
  bool enable_ABOM = true;

  // Automatic Wake-Up Management
  bool enable_AWMU = false;

  // No auto retransmit
  bool enable_ART = false;

  // Time Triggered Communication Mode
  bool enable_TTCM = false;

  // Transmit Chronologically
  bool enable_TXFP = true;

  // Receive FIFO Locked Mode
  bool enable_RFLM = false;

  // Initialize the CAN bus
  uint32_t Mode = CAN_MODE_NORMAL;

  // Configure Timing (maybe should be defines?)
  uint32_t time_sjw = CAN_SJW_1TQ;
  uint32_t time_seg_1 = CAN_BS1_13TQ;
  uint32_t time_seg_2 = CAN_BS2_2TQ;

#if defined(STM32F0)

#elif defined(STM32F3)
  time_seg_1 = CAN_BS1_6TQ;
  time_seg_2 = CAN_BS2_1TQ;
#elif defined(STM32F4)

#endif

  // Exit Sleep Mode
  CLEAR_BIT(can->MCR, CAN_MCR_SLEEP);

  // Wait to exit Sleep mode  (TODO: This timeout doesn't work)
  tickstamp = System_Tick;
  while(READ_BIT(can->MSR, CAN_MSR_SLAK)){
    if((System_Tick - tickstamp) > timeout){
      return false;
    }
  }

  // Enter Initialization Mode
  SET_BIT(can->MCR, CAN_MCR_INRQ);

  tickstamp = System_Tick;
  while(!READ_BIT(can->MSR, CAN_MSR_INAK)){
    if((System_Tick - tickstamp) > timeout){
      return false;
    }
  }

  // Automatic bus-off management
  if(enable_ABOM){
    SET_BIT(can->MCR, CAN_MCR_ABOM);
  }else{
    CLEAR_BIT(can->MCR, CAN_MCR_ABOM);
  }

  // Automatic Wake-Up Mode
  if(enable_AWMU){
    SET_BIT(can->MCR, CAN_MCR_AWUM);
  }else{
    CLEAR_BIT(can->MCR, CAN_MCR_AWUM);
  }

  // Automatic Retransmission
  if(enable_ART){
    CLEAR_BIT(can->MCR, CAN_MCR_NART);
  }else{
    SET_BIT(can->MCR, CAN_MCR_NART);
  }

  // Receive FIFO Locked Mode
  if(enable_RFLM){
    SET_BIT(can->MCR, CAN_MCR_RFLM);
  }else{
    CLEAR_BIT(can->MCR, CAN_MCR_RFLM);
  }

  // Time Triggered Communication Mode
  if(enable_TTCM){
    SET_BIT(can->MCR, CAN_MCR_TTCM);
  }else{
    CLEAR_BIT(can->MCR, CAN_MCR_TTCM);
  }

  // Transmit FIFO priority
  if(enable_TXFP){
    SET_BIT(can->MCR, CAN_MCR_TXFP);
  }else{
    CLEAR_BIT(can->MCR, CAN_MCR_TXFP);
  }

  // Setup Bus Timing
  WRITE_REG(can->BTR, (uint32_t) (Mode
                                  | time_sjw
                                  | time_seg_1
                                  | time_seg_2
                                  | (prescaler - 1U)));

  // Leave initialization mode
  CLEAR_BIT(can->MCR, CAN_MCR_INRQ);

  // Wait until device is ready
  tickstamp = System_Tick;
  while(READ_BIT(can->MSR, CAN_MSR_INAK)){
    if((System_Tick - tickstamp) > timeout){
      return false;
    }
  }

#if defined(STM32F0)
  can->IER |= CAN_IT_RX_FIFO0_MSG_PENDING | CAN_IT_ERROR;
#elif defined(STM32F3)
  can->IER |= CAN_IT_RX_FIFO0_MSG_PENDING;
#elif defined(STM32F4)
  // Enable Interrupts
  can->IER |= CAN_IT_RX_FIFO0_MSG_PENDING | CAN_IT_ERROR;
#endif
//  can->IER |= (CAN_IT_ERROR_WARNING | CAN_IT_ERROR_PASSIVE
//               | CAN_IT_LAST_ERROR_CODE | CAN_IT_ERROR
//               | CAN_IT_RX_FIFO0_MSG_PENDING | CAN_IT_RX_FIFO0_OVERRUN);
  return true;
}

bool bxCAN_Receive(CAN_TypeDef *can,
                   uint32_t fifo,
                   CAN_RxHeaderTypeDef *header,
                   uint8_t payload[]){

  if(((fifo == CAN_RX_FIFO0) && ((can->RF0R & CAN_RF0R_FMP0) == RESET))
     || ((fifo == CAN_RX_FIFO1) && ((can->RF1R & CAN_RF1R_FMP1) == RESET))){
    return false;
  }

#if 0
#if defined(STM32F0)

  if(((fifo == CAN_RX_FIFO0) && ((can->RF0R & CAN_RF0R_FMP0) == RESET))
     || ((fifo == CAN_RX_FIFO1) && ((can->RF1R & CAN_RF1R_FMP1) == RESET))){
    return false;
  }

#elif  defined(STM32F3) ||  defined(STM32F4)
  // Make sure queues' are not empty
  if(((fifo == CAN_RX_FIFO0) && ((can->RF0R & CAN_RF0R_FMP0) == RESET))
     || ((fifo == CAN_RX_FIFO1) && ((can->RF1R & CAN_RF1R_FMP1) == RESET))){
    return false;
  }
#endif
#endif

  // Load Header
  header->IDE = CAN_RI0R_IDE & can->sFIFOMailBox[fifo].RIR;
  if(header->IDE == CAN_ID_STD){
    header->StdId = (CAN_RI0R_STID & can->sFIFOMailBox[fifo].RIR) >> CAN_TI0R_STID_Pos;
  }else{
    header->ExtId = ((CAN_RI0R_EXID | CAN_RI0R_STID) & can->sFIFOMailBox[fifo].RIR) >> CAN_RI0R_EXID_Pos;
  }

  header->RTR = (CAN_RI0R_RTR & can->sFIFOMailBox[fifo].RIR) >> CAN_RI0R_RTR_Pos;
  header->DLC = (CAN_RDT0R_DLC & can->sFIFOMailBox[fifo].RDTR) >> CAN_RDT0R_DLC_Pos;
  header->FilterMatchIndex = (CAN_RDT0R_FMI & can->sFIFOMailBox[fifo].RDTR) >> CAN_RDT0R_FMI_Pos;
  header->Timestamp = (CAN_RDT0R_TIME & can->sFIFOMailBox[fifo].RDTR) >> CAN_RDT0R_TIME_Pos;

  // And the data
  payload[0] = (CAN_RDL0R_DATA0 & can->sFIFOMailBox[fifo].RDLR) >> CAN_RDL0R_DATA0_Pos;
  payload[1] = (CAN_RDL0R_DATA1 & can->sFIFOMailBox[fifo].RDLR) >> CAN_RDL0R_DATA1_Pos;
  payload[2] = (CAN_RDL0R_DATA2 & can->sFIFOMailBox[fifo].RDLR) >> CAN_RDL0R_DATA2_Pos;
  payload[3] = (CAN_RDL0R_DATA3 & can->sFIFOMailBox[fifo].RDLR) >> CAN_RDL0R_DATA3_Pos;
  payload[4] = (CAN_RDH0R_DATA4 & can->sFIFOMailBox[fifo].RDHR) >> CAN_RDH0R_DATA4_Pos;
  payload[5] = (CAN_RDH0R_DATA5 & can->sFIFOMailBox[fifo].RDHR) >> CAN_RDH0R_DATA5_Pos;
  payload[6] = (CAN_RDH0R_DATA6 & can->sFIFOMailBox[fifo].RDHR) >> CAN_RDH0R_DATA6_Pos;
  payload[7] = (CAN_RDH0R_DATA7 & can->sFIFOMailBox[fifo].RDHR) >> CAN_RDH0R_DATA7_Pos;

#if defined(STM32F0)

  if(fifo == CAN_RX_FIFO0){
    SET_BIT(can->RF0R, CAN_RF0R_RFOM0);
    CLEAR_BIT(CAN->IER, CAN_FLAG_FOV0);
  }else if(fifo == CAN_RX_FIFO1){
    SET_BIT(can->RF1R, CAN_RF1R_RFOM1);
    CLEAR_BIT(CAN->IER, CAN_FLAG_FOV1);
  }

#elif defined(STM32F3) || defined(STM32F4)
  if(fifo == CAN_RX_FIFO0){
    SET_BIT(can->RF0R, CAN_RF0R_RFOM0);
  }else if(fifo == CAN_RX_FIFO1){
    SET_BIT(can->RF1R, CAN_RF1R_RFOM1);
  }
#endif

#if ENABLE_TRANSPORT_STATS

  uint8_t can_unit = 0;

#if defined(CAN2)
  if(can == CAN2){
    can_unit = 1;
  }
#endif

#if defined(CAN3)
  if(can == CAN3){
    can_unit = 2;
  }
#endif

  ++interface_stats[can_unit].frames_rx;
#endif


  return true;
}

bool bxCAN_Transmit(CAN_TypeDef *can,
                    CAN_TxHeaderTypeDef *header,
                    const uint8_t payload[],
                    uint32_t timeout){


  uint32_t mailbox = 0;

  // Find an empty mailbox
  bool mailbox_found = false;

  uint32_t tick = System_Tick;

  // Find an empty mailbox
  while((System_Tick - tick) < timeout){
    tick = System_Tick;

//#if defined(STM32F0)
//    if(((can->TSR & CAN_TSR_TME0) != 0U) ||
//       ((can->TSR & CAN_TSR_TME1) != 0U) ||
//       ((can->TSR & CAN_TSR_TME2) != 0U)){
//#elif defined(STM32F3) || defined(STM32F4)
//      if(READ_BIT(can->TSR, CAN_TSR_TME0)
//       || READ_BIT(can->TSR, CAN_TSR_TME1)
//       || READ_BIT(can->TSR, CAN_TSR_TME2)){
//#endif

    if(READ_BIT(can->TSR, CAN_TSR_TME0)
       || READ_BIT(can->TSR, CAN_TSR_TME1)
       || READ_BIT(can->TSR, CAN_TSR_TME2)){

      mailbox = (can->TSR & CAN_TSR_CODE) >> CAN_TSR_CODE_Pos;
      mailbox_found = true;
      break;
    }
  }

  if(!mailbox_found){
    return false;
  }

  // ID
#if defined(STM32F0) // TODO: Cleanup?
  if(header->IDE == CAN_ID_STD){
    can->sTxMailBox[mailbox].TIR = ((header->StdId << CAN_TI0R_STID_Pos) |
                                    header->RTR);
  }else{
    can->sTxMailBox[mailbox].TIR = ((header->ExtId << CAN_TI0R_EXID_Pos) |
                                    header->IDE |
                                    header->RTR);
  }

#elif defined(STM32F3) || defined(STM32F4)
  can->sTxMailBox[mailbox].TIR &= CAN_TI0R_TXRQ;
  if(header->IDE == CAN_ID_STD){
    can->sTxMailBox[mailbox].TIR |= ((header->StdId << CAN_TI0R_STID_Pos)
                                     | header->RTR);
  }else{
    can->sTxMailBox[mailbox].TIR |= ((header->ExtId << CAN_TI0R_EXID_Pos)
                                     | header->IDE
                                     | header->RTR);
  }
#else
#error Unimplemented
#endif

  // Data Length
  can->sTxMailBox[mailbox].TDTR = header->DLC;

#if 0
#if defined(STM32F0) || defined(STM32F4)
  if(header->TransmitGlobalTime == ENABLE){
    SET_BIT(can->sTxMailBox[mailbox].TDTR, CAN_TDT0R_TGT);
  }
#endif
#endif

  WRITE_REG(can->sTxMailBox[mailbox].TDHR,
            ((uint32_t) payload[7] << CAN_TDH0R_DATA7_Pos)
            | ((uint32_t) payload[6] << CAN_TDH0R_DATA6_Pos)
            | ((uint32_t) payload[5] << CAN_TDH0R_DATA5_Pos)
            | ((uint32_t) payload[4] << CAN_TDH0R_DATA4_Pos));

  /* Set up the data field */
  WRITE_REG(can->sTxMailBox[mailbox].TDLR,
            ((uint32_t) payload[3] << CAN_TDL0R_DATA3_Pos)
            | ((uint32_t) payload[2] << CAN_TDL0R_DATA2_Pos)
            | ((uint32_t) payload[1] << CAN_TDL0R_DATA1_Pos)
            | ((uint32_t) payload[0] << CAN_TDL0R_DATA0_Pos));

  // Queue-Up Transmission
  SET_BIT(can->sTxMailBox[mailbox].TIR, CAN_TI0R_TXRQ);

#if ENABLE_TRANSPORT_STATS

  uint8_t can_unit = 0;

#if defined(CAN2)
  if(can == CAN2){
    can_unit = 1;
  }
#endif

#if defined(CAN3)
  if(can == CAN3){
    can_unit = 2;
  }
#endif
  ++interface_stats[can_unit].frames_tx;
#endif

  return true;
}


/**
 * Setup id-mask filtering
 *
 * @param can
 * @param FilterNumber
 * @param FilterId
 * @param FilterMask
 * @return
 */
void bxCAN_Config_Filter(CAN_TypeDef *can,
                         uint8_t FilterNumber,
                         uint32_t FilterIdHigh,
                         uint32_t FilterIdLow,
                         uint32_t FilterMaskIdHigh,
                         uint32_t FilterMaskIdLow){

  uint32_t filter_bit = 1U << FilterNumber;

  SET_BIT(can->FMR, CAN_FMR_FINIT);

#if defined(STM32F3)

#elif defined(STM32F4)
  // Either 28 filter banks shared between CAN1, CAN2. Or 14 banks for single interface
  // We only care about multi-interface STM32F4s.
  // This parameter sets the first index of filters for the slave address. Setting it to
  // zero and only activating one CAN interface assigns all of the filters to that interface
  CLEAR_BIT(can->FMR, CAN_FMR_CAN2SB);
#endif

  // Deactivate Filter
  CLEAR_BIT(can->FA1R, filter_bit);

  // 32-bit scale
  SET_BIT(can->FS1R, filter_bit);

  can->sFilterRegister[FilterNumber].FR1 = ((0x0000FFFFU & (uint32_t) FilterIdHigh) << 16U)
                                           | (0x0000FFFFU & (uint32_t) FilterIdLow);

  can->sFilterRegister[FilterNumber].FR2 = ((0x0000FFFFU & (uint32_t) FilterMaskIdHigh) << 16U)
                                           | (0x0000FFFFU & (uint32_t) FilterMaskIdLow);

  // Id/Mask mode
  CLEAR_BIT(can->FM1R, filter_bit);

  // Send to FIFO-0
  CLEAR_BIT(can->FFA1R, filter_bit);

  // Activate filter
  SET_BIT(can->FA1R, filter_bit);

  // Leave Init mode
  CLEAR_BIT(can->FMR, ((uint32_t) CAN_FMR_FINIT));
}

void bxCAN_Config_Filters(CAN_TypeDef *can,
                          uint8_t filter_count,
                          const uint32_t *filters){

  for(int i = 0; i < filter_count; ++i){
    uint32_t filter_id = *(filters++);
    uint32_t filter_mask = *(filters++);

    uint32_t id_high = (uint32_t) (filter_id >> 13U);
    uint32_t id_low = (uint32_t) ((0x00FFU & (filter_id << 3U)) | 0x04U);
    uint32_t mask_high = (uint32_t) (filter_mask >> 13U);
    uint32_t mask_low = (uint32_t) ((0x00FFU & (filter_mask << 3U)) | 0x04U);

    bxCAN_Config_Filter(can, i, id_high, id_low, mask_high, mask_low);
  }
}


/**
 *  FLASH
 */

#if defined(FIRMWARE_PAGE_COUNT)

/**
 * Erase the entire firmware block
 * @return
 */
bool Flash_Erase_Pages(uint32_t base_address,
                       uint8_t page_count){

  // Unlock
  WRITE_REG(FLASH->KEYR, FLASH_KEY1);
  WRITE_REG(FLASH->KEYR, FLASH_KEY2);

  // Wait
  while((FLASH->SR & FLASH_SR_BSY) != 0);

  FLASH->SR = (FLASH_FLAG_EOP);

  for(int i = 0; i < page_count; ++i){

    // Erase
    SET_BIT(FLASH->CR, FLASH_CR_PER);
    WRITE_REG(FLASH->AR, base_address);
    SET_BIT(FLASH->CR, FLASH_CR_STRT);

    // Wait
    while((FLASH->SR & FLASH_SR_BSY) != 0);

    // End of Op (works on F0, F3, F4)
    FLASH->SR = FLASH_FLAG_EOP;

    CLEAR_BIT(FLASH->CR, FLASH_CR_PER);

    base_address += FLASH_PAGE_SIZE;
  }

  // Disable page write and lock flash
  FLASH->CR &= ~FLASH_CR_PER;
  SET_BIT(FLASH->CR, FLASH_CR_LOCK);

  return true;
}

#endif

#if defined(FIRMWARE_SECTOR_COUNT)

#if defined(STM32F4)

bool Flash_Wait_For_Operations(uint32_t timeout){
  uint32_t tickstart = System_Tick;
  timeout = MIN(timeout, 0xFFFFFFFFU);

  while(FLASH->SR & FLASH_SR_BSY){
    if((timeout == 0U) || ((System_Tick - tickstart) > timeout)){
      return false;
    }
  }

  if(FLASH->SR & FLASH_SR_EOP){
    FLASH->SR = FLASH_SR_EOP;
  }

#if defined(FLASH_SR_RDERR)
  if(FLASH->SR & (FLASH_SR_SOP
                  | FLASH_SR_WRPERR
                  | FLASH_SR_PGAERR
                  | FLASH_SR_PGPERR
                  | FLASH_SR_PGSERR
                  | FLASH_SR_RDERR))
#else
    if(FLASH->SR & (FLASH_SR_SOP | FLASH_SR_WRPERR | FLASH_SR_PGAERR | FLASH_SR_PGPERR | FLASH_SR_PGSERR))
#endif
  {
    return false;
  }

  return true;
}

#endif

uint32_t Flash_Get_Sector_Base_Address(uint32_t sector){

  const uint32_t addresses[] = {0x08000000U,
                                0x08004000U,
                                0x08008000U,
                                0x0800C000U,
                                0x08010000U,
                                0x08020000U,
                                0x08040000U,
                                0x08060000U,
                                0x08080000U,
                                0x080A0000U,
                                0x080C0000U,
                                0x080E0000U,
                                0x08100000U,
                                0x08120000U,
                                0x08140000U,
                                0x08160000U};

  return addresses[sector];
}

uint32_t Flash_Get_Sector_Size(uint32_t sector){
  if(sector < 4){
    return 16 * 1024;
  }else if(sector == 4){
    return 64 * 1024;
  }else{
    return 128 * 1024;
  }
}

bool Flash_Is_Sector_Empty(uint32_t sector){
  uint32_t sector_start_address = Flash_Get_Sector_Base_Address(sector);
  uint32_t end_address = sector_start_address + Flash_Get_Sector_Size(sector);

  bool empty = true;

  for(uint32_t address = sector_start_address; address < end_address; address += 4){
    if(*((uint32_t *) address) != 0xFFFFFFFF){
      return false;
    }
  }

  return empty;
}

bool Flash_Erase_Sectors(uint32_t sector_start,
                         uint8_t sector_count){

  __disable_irq();

  Flash_Wait_For_Operations(50000U);

  for(uint32_t sector = sector_start; sector < sector_start + sector_count; ++sector){

    // No point in erasing empty sectors
    if(Flash_Is_Sector_Empty(sector)){
      continue;
    }

    // Unlock
    FLASH->KEYR = FLASH_KEY1;
    FLASH->KEYR = FLASH_KEY2;

    // Program the parallelism size
    FLASH->CR &= ~FLASH_CR_PSIZE;

#if STM32F4_FLASH_VOLTAGE_RANGE == 1
    // 1.8V to 2.1V
    FLASH->CR |= FLASH_PSIZE_BYTE;
#elif STM32F4_FLASH_VOLTAGE_RANGE == 2
    // 2.1V to 2.7V
    FLASH->CR |= FLASH_PSIZE_HALF_WORD;
#elif STM32F4_FLASH_VOLTAGE_RANGE == 3
    // 2.7V to 3.6V
    FLASH->CR |= FLASH_PSIZE_WORD;
#elif STM32F4_FLASH_VOLTAGE_RANGE == 4
    // 2.7V to 3.6V + external Vpp (from stm32f4xx_hal_flash_ex.h)
    FLASH->CR |= FLASH_PSIZE_DOUBLE_WORD;
#endif

    FLASH->CR &= ~FLASH_CR_SNB;

    FLASH->CR |= FLASH_CR_SER | (sector << FLASH_CR_SNB_Pos);
    FLASH->CR |= FLASH_CR_STRT;

    Flash_Wait_For_Operations(50000U);

    FLASH->CR &= ~(FLASH_CR_SER | FLASH_CR_SNB);

    // Lock the flash
    FLASH->CR |= FLASH_CR_LOCK;
  }

  // Flush Instruction Caches
  if(READ_BIT(FLASH->ACR, FLASH_ACR_ICEN) != RESET){
    // Disable instruction cache
    FLASH->ACR &= ~FLASH_ACR_ICEN;

    // Reset instruction cache
    FLASH->ACR |= FLASH_ACR_ICRST;
    FLASH->ACR &= ~FLASH_ACR_ICRST;

    // Enable instruction cache
    FLASH->ACR |= FLASH_ACR_ICEN;
  }

  // Flush Data Cache
  if(READ_BIT(FLASH->ACR, FLASH_ACR_DCEN) != RESET){
    // Disable data cache
    FLASH->ACR &= ~FLASH_ACR_DCEN;
    // Reset data cache
    FLASH->ACR |= FLASH_ACR_DCRST;
    FLASH->ACR &= ~FLASH_ACR_DCRST;
    // Enable data cache
    FLASH->ACR |= FLASH_ACR_DCEN;
  }

  __enable_irq();

  return true;
}

#endif

/**
 * Write data in blocks of 1k using half-words
 *
 * @param data
 * @param data_len
 */
bool Flash_Write_Block(uint32_t memory_offset,
                       const uint8_t *buffer,
                       uint32_t buffer_len){
  __disable_irq();

  // Wait for any pending operations
  while((FLASH->SR & FLASH_SR_BSY) != 0);

#if !defined(STM32F0)
  FLASH->SR = FLASH_SR_EOP;
#endif

  // Unlock
  FLASH->KEYR = FLASH_KEY1;
  FLASH->KEYR = FLASH_KEY2;

#if defined(STM32F3)
  FLASH->SR = (FLASH_SR_EOP | FLASH_SR_WRPERR | FLASH_SR_PGERR);
#elif defined(STM32F4)
  FLASH->SR = FLASH_SR_EOP | FLASH_SR_SOP | FLASH_SR_WRPERR | FLASH_SR_PGAERR
              | FLASH_SR_PGPERR | FLASH_SR_PGSERR;

  // Program the parallelism size
  CLEAR_BIT(FLASH->CR, FLASH_CR_PSIZE);

#if STM32F4_FLASH_VOLTAGE_RANGE < 2
#error "Only 2.1 - 3.67 range is supported, but we write HALF_WORDs"
#endif

  FLASH->CR |= FLASH_PSIZE_HALF_WORD;
#endif

  // We can go past the end of the buffer here, size of buffer should be even.
  uint32_t buffer_hword_count = (buffer_len + 1) / 2;

  for(int i = 0; i < buffer_hword_count; ++i){

    uint16_t data = (uint16_t) buffer[2 * i + 1] << 8U
                    | ((uint16_t) buffer[2 * i + 0]);

    FLASH->CR |= FLASH_CR_PG;

    *(volatile uint16_t *) (memory_offset + 2 * i) = data;

    // Wait for operation to finish
    do{
      __ASM volatile ("nop");
    }while((FLASH->SR & FLASH_SR_BSY) != 0);
  }

  // Lock flash
  FLASH->CR |= FLASH_CR_LOCK;

  do{
    __ASM volatile ("nop");
  }while((FLASH->SR & FLASH_SR_BSY) != 0);

  bool verified = true;

  for(int i = 0; i < buffer_hword_count; ++i){

    uint16_t data = ((uint16_t) buffer[2 * i + 1]) << 8U
                    | ((uint16_t) buffer[2 * i + 0]);

    if(*(__IO uint16_t *) (memory_offset + 2 * i) != data){
      verified = false;
      break;
    }
  }

  __enable_irq();

  return verified;
}

/**
 * GPIO
 */

#define GPIO_MODE             (0x00000003U)
#define EXTI_MODE             (0x10000000U)
#define GPIO_MODE_IT          (0x00010000U)
#define GPIO_MODE_EVT         (0x00020000U)
#define RISING_EDGE           (0x00100000U)
#define FALLING_EDGE          (0x00200000U)
#define GPIO_OUTPUT_TYPE      (0x00000010U)

void GPIO_Config_Pins(GPIO_TypeDef *GPIOx,
                      uint32_t Pin,
                      uint32_t Mode,
                      uint32_t Type,
                      uint32_t Pull,
                      uint32_t Speed){
  uint32_t position = 0x00U;
  uint32_t iocurrent = 0x00U;

#if defined(STM32F0)

  while(((Pin) >> position) != 0x00u){
    iocurrent = (Pin) & (0x00000001uL << position);

    if(iocurrent != 0x00u){
      LL_GPIO_SetPinMode(GPIOx, iocurrent, Mode);

      if((Mode == LL_GPIO_MODE_OUTPUT) || (Mode == LL_GPIO_MODE_ALTERNATE)){
        LL_GPIO_SetPinSpeed(GPIOx, iocurrent, Speed);
      }

      LL_GPIO_SetPinPull(GPIOx, iocurrent, Pull);

#if 0
      if(Mode == LL_GPIO_MODE_ALTERNATE){
        if(iocurrent < LL_GPIO_PIN_8){
          LL_GPIO_SetAFPin_0_7(GPIOx, iocurrent, Alternate);
        }else{
          LL_GPIO_SetAFPin_8_15(GPIOx, iocurrent, Alternate);
        }
      }
#endif
    }
    position++;
  }

  if((Mode == LL_GPIO_MODE_OUTPUT) || (Mode == LL_GPIO_MODE_ALTERNATE)){
    LL_GPIO_SetPinOutputType(GPIOx, Pin, Type);
  }

#elif defined(STM32F3)
  uint32_t temp = 0x00U;

  while((Pin >> position)){
    iocurrent = Pin & (1U << position);

    if(iocurrent){
      /* In case of Alternate function mode selection */
      if((Mode == GPIO_MODE_AF_PP) || (Mode == GPIO_MODE_AF_OD)){

        // Configure Alternate function
        temp = GPIOx->AFR[position >> 3U];
        CLEAR_BIT(temp, 0xFU << ((uint32_t) (position & 0x07U) * 4U));
//        SET_BIT(temp, (uint32_t) (Alternate) << (((uint32_t) position & 0x07U) * 4U));
        GPIOx->AFR[position >> 3U] = temp;
      }

      // Configure IO Direction mode (Input, Output, Alternate or Analog)
      CLEAR_BIT(GPIOx->MODER, GPIO_MODER_MODER0 << (position * 2U));
      SET_BIT(GPIOx->MODER, (Mode & GPIO_MODE) << (position * 2U));

      // Output or Alternate function mode selection
      if((Mode == GPIO_MODE_OUTPUT_PP) || (Mode == GPIO_MODE_AF_PP) ||
         (Mode == GPIO_MODE_OUTPUT_OD) || (Mode == GPIO_MODE_AF_OD)){

        CLEAR_BIT(GPIOx->OSPEEDR, GPIO_OSPEEDER_OSPEEDR0 << (position * 2U));
        SET_BIT(GPIOx->OSPEEDR, Speed << (position * 2U));

        CLEAR_BIT(GPIOx->OTYPER, GPIO_OTYPER_OT_0 << position);
        SET_BIT(GPIOx->OTYPER, ((Mode & GPIO_OUTPUT_TYPE) >> 4U) << position);
      }

      // Activate the Pull-up or Pull down resistor for the current IO */
      CLEAR_BIT(GPIOx->PUPDR, GPIO_PUPDR_PUPDR0 << (position * 2U));
      SET_BIT(GPIOx->PUPDR, (Pull) << (position * 2U));
    }

    position++;
  }
#elif defined(STM32F4)
  uint32_t temp = 0x00U;
  uint32_t ioposition = 0x00U;

  /* Configure the port pins */
  for(position = 0U; position < GPIO_NUMBER; position++){
    /* Get the IO position */
    ioposition = 0x01U << position;
    /* Get the current IO position */
    iocurrent = (uint32_t) (Pin) & ioposition;

    if(iocurrent != ioposition){
      continue;
    }

    /*--------------------- GPIO Mode Configuration ------------------------*/
    /* In case of Alternate function mode selection */
    if((Mode == GPIO_MODE_AF_PP) || (Mode == GPIO_MODE_AF_OD)){
      /* Configure Alternate function mapped with the current IO */
      temp = GPIOx->AFR[position >> 3U];
      temp &= ~(0xFU << ((uint32_t) (position & 0x07U) * 4U));
//      temp |= ((uint32_t) (Alternate) << (((uint32_t) position & 0x07U) * 4U));
      GPIOx->AFR[position >> 3U] = temp;
    }

    /* Configure IO Direction mode (Input, Output, Alternate or Analog) */
    temp = GPIOx->MODER;
    temp &= ~(GPIO_MODER_MODER0 << (position * 2U));
    temp |= ((Mode & GPIO_MODE) << (position * 2U));
    GPIOx->MODER = temp;

    /* In case of Output or Alternate function mode selection */
    if((Mode == GPIO_MODE_OUTPUT_PP) || (Mode == GPIO_MODE_AF_PP) ||
       (Mode == GPIO_MODE_OUTPUT_OD) || (Mode == GPIO_MODE_AF_OD)){

      /* Configure the IO Speed */
      temp = GPIOx->OSPEEDR;
      temp &= ~(GPIO_OSPEEDER_OSPEEDR0 << (position * 2U));
      temp |= (Speed << (position * 2U));
      GPIOx->OSPEEDR = temp;

      /* Configure the IO Output Type */
      temp = GPIOx->OTYPER;
      temp &= ~(GPIO_OTYPER_OT_0 << position);
      temp |= (((Mode & GPIO_OUTPUT_TYPE) >> 4U) << position);
      GPIOx->OTYPER = temp;
    }

    /* Activate the Pull-up or Pull down resistor for the current IO */
    temp = GPIOx->PUPDR;
    temp &= ~(GPIO_PUPDR_PUPDR0 << (position * 2U));
    temp |= ((Pull) << (position * 2U));
    GPIOx->PUPDR = temp;

  }
#endif
}

#if !defined(GPIO_GET_INDEX)
#if defined(GPIOE)
#define GPIO_GET_INDEX(__GPIOx__)    (((__GPIOx__) == (GPIOA))? 0U :\
                                      ((__GPIOx__) == (GPIOB))? 1U :\
                                      ((__GPIOx__) == (GPIOC))? 2U :\
                                      ((__GPIOx__) == (GPIOD))? 3U :\
                                      ((__GPIOx__) == (GPIOE))? 4U : 5U)
#else
#define GPIO_GET_INDEX(__GPIOx__)    (((__GPIOx__) == (GPIOA))? 0U :\
                                      ((__GPIOx__) == (GPIOB))? 1U :\
                                      ((__GPIOx__) == (GPIOC))? 2U :\
                                      ((__GPIOx__) == (GPIOD))? 3U : 4U)
#endif
#endif

void GPIO_Config_Pins_EXTI(GPIO_TypeDef *GPIOx,
                           uint32_t Pin,
                           uint32_t Mode){
#if defined(STM32F4)

  for(uint32_t position = 0U; position < GPIO_NUMBER; position++){

    uint32_t ioposition = 0x01U << position;
    uint32_t iocurrent = (uint32_t) (Pin) & ioposition;

    if(iocurrent == ioposition){

      uint32_t temp = SYSCFG->EXTICR[position >> 2U];
      temp &= ~(0x0FU << (4U * (position & 0x03U)));
      temp |= ((uint32_t) (GPIO_GET_INDEX(GPIOx)) << (4U * (position & 0x03U)));
      SYSCFG->EXTICR[position >> 2U] = temp;

      EXTI->IMR &= ~((uint32_t) iocurrent);
      if((Mode & GPIO_MODE_IT) == GPIO_MODE_IT){
        EXTI->IMR |= iocurrent;
      }

      EXTI->EMR &= ~((uint32_t) iocurrent);
      if((Mode & GPIO_MODE_EVT) == GPIO_MODE_EVT){
        EXTI->EMR |= iocurrent;
      }

      EXTI->RTSR &= ~((uint32_t) iocurrent);
      if((Mode & RISING_EDGE) == RISING_EDGE){
        EXTI->RTSR |= iocurrent;
      }

      EXTI->FTSR &= ~((uint32_t) iocurrent);
      if((Mode & FALLING_EDGE) == FALLING_EDGE){
        EXTI->FTSR |= iocurrent;
      }
    }

  }

#else

  uint32_t position = 0x00U;

  SET_BIT(RCC->APB2ENR, RCC_APB2ENR_SYSCFGEN);

  while((Pin >> position)){

    uint32_t iocurrent = Pin & (1U << position);

    if(iocurrent){

      uint32_t temp = SYSCFG->EXTICR[position >> 2U];
      CLEAR_BIT(temp, (0x0FU) << (4U * (position & 0x03U)));
      SET_BIT(temp, (GPIO_GET_INDEX(GPIOx)) << (4U * (position & 0x03U)));
      SYSCFG->EXTICR[position >> 2U] = temp;

      CLEAR_BIT(EXTI->IMR, (uint32_t) iocurrent);
      if((Mode & GPIO_MODE_IT) == GPIO_MODE_IT){
        SET_BIT(EXTI->IMR, iocurrent);
      }

      CLEAR_BIT(EXTI->EMR, (uint32_t) iocurrent);
      if((Mode & GPIO_MODE_EVT) == GPIO_MODE_EVT){
        SET_BIT(EXTI->EMR, iocurrent);
      }

      CLEAR_BIT(EXTI->RTSR, (uint32_t) iocurrent);
      if((Mode & RISING_EDGE) == RISING_EDGE){
        SET_BIT(EXTI->RTSR, iocurrent);
      }

      CLEAR_BIT(EXTI->FTSR, (uint32_t) iocurrent);
      if((Mode & FALLING_EDGE) == FALLING_EDGE){
        SET_BIT(EXTI->FTSR, iocurrent);
      }
    }
    position++;
  }
#endif
}

void GPIO_DeConfig_Pins(GPIO_TypeDef *GPIOx,
                        uint32_t GPIO_Pin){

  uint32_t position = 0;

  while((GPIO_Pin >> position) != RESET){

    uint32_t iocurrent = GPIO_Pin & (1U << position);

    if(iocurrent){
      // Configure IO Direction in Input Floating Mode
      CLEAR_BIT(GPIOx->MODER, GPIO_MODER_MODER0 << (position * 2U));

      // Configure the default Alternate Function
      CLEAR_BIT(GPIOx->AFR[position >> 3U], 0xFU << ((uint32_t) (position & 0x07U) * 4U));

      // Clear IO Speed
      CLEAR_BIT(GPIOx->OSPEEDR, GPIO_OSPEEDER_OSPEEDR0 << (position * 2U));

      // Clear IO Output Type
      CLEAR_BIT(GPIOx->OTYPER, GPIO_OTYPER_OT_0 << position);

      // Deactivate the Pull-up and Pull-down resistor
      CLEAR_BIT(GPIOx->PUPDR, GPIO_PUPDR_PUPDR0 << (position * 2U));

      // Clear EXTI Configuration
      uint32_t tmp = SYSCFG->EXTICR[position >> 2U];
      tmp &= ((0x0FU) << (4U * (position & 0x03U)));
      if(tmp == (GPIO_GET_INDEX(GPIOx) << (4U * (position & 0x03U)))){
        tmp = (0x0FU) << (4U * (position & 0x03U));
        CLEAR_BIT(SYSCFG->EXTICR[position >> 2U], tmp);

        /* Clear EXTI line configuration */
        CLEAR_BIT(EXTI->IMR, (uint32_t) iocurrent);
        CLEAR_BIT(EXTI->EMR, (uint32_t) iocurrent);

        /* Clear Rising Falling edge configuration */
        CLEAR_BIT(EXTI->RTSR, (uint32_t) iocurrent);
        CLEAR_BIT(EXTI->FTSR, (uint32_t) iocurrent);
      }
    }

    position++;
  }
}

/**
 * I2C
 */

bool I2C_Read_Register(I2C_TypeDef *hi2c,
                       uint8_t address_7bit,
                       uint8_t register_address,
                       size_t data_length,
                       uint8_t *data){

#if defined(STM32F3)

  // Setup I2C transfer
  LL_I2C_HandleTransfer(hi2c,
                        address_7bit,
                        LL_I2C_ADDRSLAVE_7BIT,
                        1,
                        LL_I2C_MODE_AUTOEND,
                        LL_I2C_GENERATE_START_WRITE);

  // Dummy write of the target register address
  while(true){
    if(LL_I2C_IsActiveFlag_TXIS(hi2c)){
      LL_I2C_TransmitData8(hi2c, register_address);
      break;
    }
  }

  // SETUP Read
  LL_I2C_HandleTransfer(hi2c,
                        address_7bit,
                        LL_I2C_ADDRSLAVE_7BIT,
                        data_length,
                        LL_I2C_MODE_AUTOEND,
                        LL_I2C_GENERATE_START_READ);

  // READ data
  for(int j = 0; j < data_length; ++j){
    while(!LL_I2C_IsActiveFlag_RXNE(hi2c)){}
    data[j] = LL_I2C_ReceiveData8(hi2c);
  }

  while(!LL_I2C_IsActiveFlag_STOP(hi2c)){
    Busy_Wait(1);
  }

  LL_I2C_ClearFlag_STOP(hi2c);

#elif defined(STM32F4)

//  LL_I2C_AcknowledgeNextData(hi2c, LL_I2C_ACK);

  LL_I2C_GenerateStartCondition(hi2c);

  // Wait for SB flag
  while(!LL_I2C_IsActiveFlag_SB(hi2c)){}

  LL_I2C_TransmitData8(hi2c, address_7bit);

  // Wait for ADDR flag
  while(!LL_I2C_IsActiveFlag_ADDR(hi2c)){};

  LL_I2C_ClearFlag_ADDR(hi2c);

  // Write register address
  if(LL_I2C_IsActiveFlag_TXE(hi2c)){
    LL_I2C_TransmitData8(hi2c, register_address);
  }

  /**
   * Read the data
   */

  // Send Start
  LL_I2C_GenerateStartCondition(hi2c);

  // Enable Acknowledge
  LL_I2C_AcknowledgeNextData(hi2c, LL_I2C_ACK);

  // Wait for SB flag to be set
  while(!LL_I2C_IsActiveFlag_SB(hi2c)){};

  // Send target address (+ Read bit)
  LL_I2C_TransmitData8(hi2c, address_7bit | 0x01);

  while(!LL_I2C_IsActiveFlag_ADDR(hi2c)){};

  LL_I2C_ClearFlag_ADDR(hi2c);

  // Start Reading
  size_t offset = 0;

  // TODO: Kinda of a hack...
  if(data_length == 1){
    LL_I2C_AcknowledgeNextData(hi2c, LL_I2C_NACK);
    LL_I2C_GenerateStopCondition(hi2c);
  }

  while(data_length > 0){

    // If there is something in the RX buffer
    // Or if the transfer is ending
    if(LL_I2C_IsActiveFlag_RXNE(hi2c) || LL_I2C_IsActiveFlag_BTF(hi2c)){

      // No. fucking. clue.
      if(data_length == 2){
        LL_I2C_AcknowledgeNextData(hi2c, LL_I2C_NACK);
        LL_I2C_GenerateStopCondition(hi2c);
      }

      data[offset++] = LL_I2C_ReceiveData8(hi2c);
      --data_length;
    }
  }
#endif
  return true;
}

bool I2C_Write_Register(I2C_TypeDef *hi2c,
                        uint8_t address_7bit,
                        uint8_t register_address,
                        size_t data_length,
                        const uint8_t *data){

#if defined(STM32F3)

  // Time out
  LL_I2C_HandleTransfer(hi2c,
                        address_7bit,
                        LL_I2C_ADDRSLAVE_7BIT,
                        data_length + 1,
                        LL_I2C_MODE_AUTOEND,
                        LL_I2C_GENERATE_START_WRITE);

  // Wait for TX buffer to be empty
  while(!LL_I2C_IsActiveFlag_TXE(hi2c)){};

  // Write the register
  LL_I2C_TransmitData8(hi2c, register_address);

  // Write the data
  for(int i = 0; i < data_length; ++i){

    // Wait for TX buffer to be empty
    while(!LL_I2C_IsActiveFlag_TXE(hi2c)){
      __asm__ volatile("nop");
    };

    // Send some data
    LL_I2C_TransmitData8(hi2c, data[i]);
  }

  // Wait for TX buffer to be empty
  while(!LL_I2C_IsActiveFlag_TXE(hi2c)){
    __asm__ volatile("nop");
  };

//  LL_I2C_GenerateStopCondition(hi2c);

#elif defined(STM32F4)

//  LL_I2C_AcknowledgeNextData(hi2c, LL_I2C_ACK);

  LL_I2C_GenerateStartCondition(hi2c);

  // Wait for SB flag
  while(!LL_I2C_IsActiveFlag_SB(hi2c)){
    __asm__ volatile("nop");
  }

  // Dummy write of address + write bit
  LL_I2C_TransmitData8(hi2c, address_7bit | 0x00);

  // Wait for ADDR flag
  while(!LL_I2C_IsActiveFlag_ADDR(hi2c)){
    __asm__ volatile("nop");
  };

  LL_I2C_ClearFlag_ADDR(hi2c);

  // Wait for TX buffer to be empty
  while(!LL_I2C_IsActiveFlag_TXE(hi2c)){
    __asm__ volatile("nop");
  };

  // Write the register
  LL_I2C_TransmitData8(hi2c, register_address);

  // Write the data
  for(int i = 0; i < data_length; ++i){

    // Wait for TX buffer to be empty
    while(!LL_I2C_IsActiveFlag_TXE(hi2c)){
      __asm__ volatile("nop");
    };

    // Send some data
    LL_I2C_TransmitData8(hi2c, data[i]);
  }

  while(!LL_I2C_IsActiveFlag_TXE(hi2c)){
    __asm__ volatile("nop");
  };

  LL_I2C_GenerateStopCondition(hi2c);
#endif
  return true;
}

/**
 * EEPROM
 */

bool EEPROM_Page_Read(I2C_TypeDef *hi2c,
                      uint8_t chip_address_7bit,
                      uint8_t start_page,
                      size_t byte_count,
                      uint8_t *p){

  const uint8_t page_size = EEPROM_PAGE_SIZE;

  // Temporary buffer
  uint8_t buffer[page_size];

  size_t page_count = (byte_count + page_size - 1) / page_size;

  // Read in pages
  for(int i = 0; i < page_count; ++i){
    size_t bytes_in_page = MIN(byte_count, page_size);

    size_t byte_offset = (start_page + i) * page_size;

    // Get the "register" address
    uint8_t register_address = 0xFF & byte_offset;
    uint8_t chip_section_address = (0x300 & byte_offset) >> 7;

    uint8_t i2c_address = chip_address_7bit | chip_section_address;

    // Read the page data
    I2C_Read_Register(hi2c,
                      i2c_address,
                      register_address,
                      bytes_in_page,
                      buffer);

    // Copy data over
    for(int j = 0; j < bytes_in_page; ++j){
      *(p++) = buffer[j];
    }
    byte_count -= bytes_in_page;

    // If this isn't here, things don't work...
    Busy_Wait(1);
  }

  return true;
}

bool EEPROM_Page_Write(I2C_TypeDef *hi2c,
                       uint8_t chip_address_7bit,
                       uint8_t start_page,
                       size_t byte_count,
                       uint8_t *p){

  const uint8_t page_size = EEPROM_PAGE_SIZE;

  uint8_t buffer[page_size];

  // Can write to the EEPROM in 16 byte pages only
  size_t page_count = (byte_count + page_size - 1) / page_size;

  // Write loop
  for(int i = 0; i < page_count; ++i){
    size_t bytes_in_page = MIN(byte_count, page_size);
    size_t byte_offset = start_page * page_size + i * page_size;

    const uint8_t register_address = 0xFF & byte_offset;
    const uint8_t chip_section_address = (0x300 & byte_offset) >> 7;

#if !(defined(ENABLE_BOOTLOADER_FUNCTIONS) && ENABLE_BOOTLOADER_FUNCTIONS == 1)
    // Only bootloader is allowed to write to section 0
    if(chip_section_address == 0){
      // This should never happen!! so when it does things have gone really bad...
      // so just 'exit' and hope things work themselves out.
      return false;
    }
#endif

    uint8_t i2c_address = chip_address_7bit | chip_section_address;

    for(int j = 0; j < bytes_in_page; ++j){
      buffer[j] = *(p++);
    }

    I2C_Write_Register(hi2c,
                       i2c_address,
                       register_address,
                       bytes_in_page,
                       buffer);

    byte_count -= bytes_in_page;

    // Write cycle for AT24C0x is 5ms
    Busy_Wait(5);
  }
  return true;
}

/**
 *
 * These can only read 1 page or less.
 *
 * @param i2c
 * @param chip_address_7bit
 * @param address
 * @param byte_count
 * @param p
 * @return
 */
bool EEPROM_Short_Read(I2C_TypeDef *i2c,
                       uint8_t chip_address_7bit,
                       uint16_t address,
                       size_t byte_count,
                       uint8_t *p){

  const uint8_t register_address = 0xFF & address;
  const uint8_t chip_section_address = (0x300 & address) >> 7;

  return I2C_Read_Register(i2c,
                           chip_address_7bit | chip_section_address,
                           register_address,
                           byte_count,
                           p);
}

bool EEPROM_Short_Write(I2C_TypeDef *i2c,
                        uint8_t chip_address_7bit,
                        uint16_t address,
                        size_t byte_count,
                        const uint8_t *p){

  // Get the "register" address
  const uint8_t register_address = 0xFF & address;
  const uint8_t chip_section_address = (0x300 & address) >> 7;

#if !(defined(ENABLE_BOOTLOADER_FUNCTIONS) && ENABLE_BOOTLOADER_FUNCTIONS == 1)
  // Only bootloader is allowed to write to section 0
  if(chip_section_address == 0){
    // This should never happen!! so when it does things have gone really bad...
    // so just 'exit' and hope things work themselves out.
    return false;
  }
#endif

  return I2C_Write_Register(i2c,
                            chip_address_7bit | chip_section_address,
                            register_address,
                            byte_count,
                            p);
}

/**
 * Bootloader
 */

/**
 * Jump into the bootloader.
 *
 * This assume the bootloader is at FLASH_BASE (0x8000000)
 *
 * Places information at the first 256 bytes of program memory.
 *
 * Make sure to disable all interrupts, dma transfers, and devices before jumping or it will crash.
 */
void Bootloader_Jump(uint32_t flash_base){

  // Get pointer to bootloader reset handler
  void (*bootloader_main)(void) = (void (*)(void)) (*((uint32_t *) (flash_base + 4)));

#if defined(STM32F0)
  //  NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x4000)
  // Remap to flash
  SYSCFG->CFGR1 &= ~SYSCFG_CFGR1_MEM_MODE;

#elif defined(STM32F3) || defined(STM32F4)
  SysTick->CTRL = 0;
  SysTick->LOAD = 0;
  SysTick->VAL = 0;

  SCB->VTOR = 0x8000000;
#endif

  // Set stack pointer
  __set_MSP(*(uint32_t *) flash_base);

  // Start
  bootloader_main();
}

/**
 * Read from I2C in pages (EEPROM)
 */

/**
 * Parameters
 *
 * @returns true if the value was loaded (and therefore this parameter is dirty)
 */
bool Params_Load_Default(int index,
                         const parameter_info_t *info_table,
                         const uint8_t *factory_info_base,
                         uint8_t *param_base){

  bool dirty = false;
  uint8_t *element_pointer = ((uint8_t *) param_base + info_table[index].struct_offset);
  uint8_t *calibration_pointer = 0;

  // Check for a factory default
  if(info_table[index].calibration_offset != 0){
    calibration_pointer = ((uint8_t *) factory_info_base + info_table[index].calibration_offset);
  }

  switch(info_table[index].type){
    case PARAM_VALUE_BOOL:
      dirty = (*(bool *) element_pointer != (bool) info_table[index].i_default);
      *(bool *) element_pointer = (bool) info_table[index].i_default;
      break;

    case PARAM_VALUE_INT:
      dirty = (*(int32_t *) element_pointer != info_table[index].i_default);
      calibration_pointer = calibration_pointer ? calibration_pointer : (uint8_t *) &info_table[index].i_default;
      // Memcpy because ints can be 8, 16, or 32 bits wide and signed / unsigned
      memcpy(element_pointer,
             calibration_pointer,
             info_table[index].variable_size);
      break;

    case PARAM_VALUE_REAL:
      dirty = (*(float *) element_pointer != info_table[index].f_default);
      *(float *) element_pointer = calibration_pointer ? *(float *) calibration_pointer : info_table[index].f_default;

      break;
  }
  return dirty;

}

void Params_Load_Defaults(size_t parameter_count,
                          const parameter_info_t *info_table,
                          const uint8_t *factory_info_base,
                          bool *dirty_table,
                          uint8_t *param_base){

  for(int i = 0; i < parameter_count; ++i){
    dirty_table[i] = dirty_table[i] | Params_Load_Default(i, info_table, factory_info_base, param_base);
  }
}


/**
 * This subroutine will load parameters from EEPROM if they are available
 * and it will also upgrade any parameters.
 *
 * @param i2c bus to use (e.g. I2C1, I2C2, I2C3, ... )
 * @param address_7bit
 * @param parameter_version Parameter version used by the current firmware
 * @param page_size EEPROM page size (e.g. 16)
 * @param header_start_page
 * @param parameter_start_page
 * @param parameter_count
 * @param info_table
 * @param param_base
 * @return 0 if everything loaded cleanly, otherwise status info.
 */
uint8_t Params_EEPROM_Load(I2C_TypeDef *i2c,
                           uint8_t address_7bit,
                           uint8_t header_start_page,
                           uint8_t parameter_start_page,
                           int parameter_version,
                           size_t parameter_count,
                           const parameter_info_t *info_table,
                           const uint8_t *factory_info_base,
                           bool *dirty_table,
                           uint8_t *param_base){

  const size_t page_size = EEPROM_PAGE_SIZE;
  const size_t parameter_offset = parameter_start_page * page_size;

  uint8_t ret_val = EEPROM_LOAD_STATE_ALL_OK;

  parameter_header_t header = {};

  // First, read the header
  EEPROM_Page_Read(i2c,
                   address_7bit,
                   header_start_page,
                   sizeof(header),
                   (uint8_t *) &header);


  // Check if there is something valid in the EEPROM
  if(header.magic != PARAMETER_HEADER_MAGIC){
    // If not, let the next loop load all the defaults
    header.version = 0;
  }

  // We are loading one page at a time
  uint8_t buffer[16];

  for(int i = 0; i < parameter_count; ++i){

    // If this parameter is newer than the parameters
    // in the EEPROM then the parameter is new
    if(header.version < info_table[i].version){
      Params_Load_Default(i, info_table, factory_info_base, param_base);
      dirty_table[i] = true;
      ret_val = EEPROM_LOAD_STATE_SOME_PARAMS_UPGRADED;
      continue;
    }

    memset(buffer, 0, sizeof(buffer));
    EEPROM_Short_Read(i2c,
                      address_7bit,
                      info_table[i].eeprom_offset + parameter_offset,
                      info_table[i].eeprom_size,
                      buffer);

    // Copy the data into memory
    for(int j = 0; j < info_table[i].eeprom_size; ++j){
      *(param_base + info_table[i].struct_offset + j) = buffer[j];
    }
  }

  if(header.magic != PARAMETER_HEADER_MAGIC){
    ret_val = EEPROM_LOAD_STATE_ALL_DEFAULTS_LOADED;
  }

  return ret_val;
}

/**
 *
 * This will only save parameters that have changed in the EEPROM
 *
 * Note: Variables can not cross a page boundary!
 *
 */
uint8_t Params_EEPROM_Save(I2C_TypeDef *i2c,
                           uint8_t address_7bit,
                           uint8_t header_start_page,
                           uint8_t parameter_start_page,
                           int parameter_version,
                           size_t parameter_count,
                           const parameter_info_t *info_table,
                           bool *dirty_table,
                           const uint8_t *param_base){

  const size_t page_size = EEPROM_PAGE_SIZE;
  const size_t parameter_offset = parameter_start_page * page_size;

  parameter_header_t header = {PARAMETER_HEADER_MAGIC,
                               parameter_version};

  uint8_t buffer[page_size];

  // Save parameters that haven't changed
  for(int i = 0; i < parameter_count; ++i){

    if(!dirty_table[i]){
      continue;
    }

    size_t eeprom_offset = info_table[i].eeprom_offset + parameter_offset;
    size_t eeprom_size = info_table[i].eeprom_size;
    size_t memory_offset = info_table[i].struct_offset;

    // Copy the data
    for(int j = 0; j < eeprom_size; ++j){
      buffer[j] = param_base[memory_offset + j];
    }

    EEPROM_Short_Write(i2c,
                       address_7bit,
                       eeprom_offset,
                       eeprom_size,
                       buffer);

    // Write cycle time
    Busy_Wait(5);
  }

  // Finally, write the header
  EEPROM_Page_Write(i2c,
                    address_7bit,
                    header_start_page,
                    sizeof(header),
                    (uint8_t *) &header);

  // Clear out the 'dirty table'
  memset(dirty_table, 0, parameter_count * sizeof(bool));
  return 0;
}


bool FactoryInfo_Load(I2C_TypeDef *i2c,
                      uint8_t address_7bit,
                      size_t struct_size,
                      uint8_t *param_base){

  const uint8_t page_size = EEPROM_PAGE_SIZE;

  factory_info_header_t *header = (factory_info_header_t *) param_base;

  // Read 1 page from EEPROM
  EEPROM_Page_Read(i2c,
                   address_7bit,
                   FACTORY_INFO_START_PAGE,
                   page_size,
                   param_base);

  if((header->magic != FACTORY_INFO_MAGIC)
     || (struct_size < header->struct_size)){

    // Zero-out the structure
    for(int i = 0; i < struct_size; ++i){
      *(param_base + i) = 0;
    }
    return false;
  }

  // Read the rest of the structure
  EEPROM_Page_Read(i2c,
                   address_7bit,
                   FACTORY_INFO_START_PAGE + 1,
                   header->struct_size - page_size,
                   (uint8_t *) (param_base + page_size));

//  return true;
  uint16_t crc_eeprom = header->crc;
  header->crc = 0U;

  // Compute CRC
  uint16_t crc = 0xFFFFU;

  for(int i = 0; i < struct_size; ++i){
    crc = CRC_16_Add_Byte(crc, param_base[i]);
  }

  header->crc = crc;

  if(crc_eeprom != crc){
    // Zero-out the structure
    for(int i = 0; i < struct_size; ++i){
      *(param_base + i) = 0;
    }
    return false;
  }

  return true;
}

/**
 * This will compute the CRC and save the structure
 */
bool FactoryInfo_Save(I2C_TypeDef *i2c,
                      uint8_t address_7bit,
                      size_t struct_size,
                      uint8_t *param_base){

  // First thing in the Factory Info should be the header
  factory_info_header_t *header = (factory_info_header_t *) param_base;

  header->magic = FACTORY_INFO_MAGIC;
  header->struct_version = FACTORY_INFO_VERSION;
  header->struct_size = struct_size;
  header->crc = 0;

  // Compute CRC
  uint16_t crc = 0xFFFFU;

  for(int i = 0; i < struct_size; ++i){
    crc = CRC_16_Add_Byte(crc, param_base[i]);
  }

  header->crc = crc;

  // Save structure
  return EEPROM_Page_Write(i2c,
                           address_7bit,
                           0,
                           struct_size,
                           param_base);
}


int Request_Queue_Add(request_queue_t *q,
                      uint16_t type_id,
                      uint8_t source_node_id,
                      uint8_t transfer_id,
                      uint8_t priority,
                      uint8_t data){

  int ix = q->end;

  q->request[ix].node_id = source_node_id;
  q->request[ix].pending = true;
  q->request[ix].priority = priority;
  q->request[ix].transfer_id = transfer_id;
  q->request[ix].type_id = type_id;
  q->request[ix].data = data;

  q->end = (q->end + 1) % REQUEST_QUEUE_CAPACITY;
  q->size = MIN(q->size + 1, REQUEST_QUEUE_CAPACITY);

  return ix;
}

/**
 *
 * Add to request queue only if the data type is not already in the queue.
 * Otherwise, overwrite.
 *
 *
 * @param type_id
 * @param source_node_id
 * @param transfer_id
 * @param priority
 * @param data
 * @return
 */
int Request_Queue_Add_Unique(request_queue_t *q,
                             uint16_t type_id,
                             uint8_t source_node_id,
                             uint8_t transfer_id,
                             uint8_t priority,
                             uint8_t data){

  for(int i = 0; i < q->size; ++i){

    int ix = (q->top + i) % REQUEST_QUEUE_CAPACITY;

    if(q->request[ix].type_id == type_id){
      q->request[ix].node_id = source_node_id;
      q->request[ix].priority = priority;
      q->request[ix].transfer_id = transfer_id;
      q->request[ix].data = data;

      return ix;
    }
  }

  return Request_Queue_Add(q,
                           type_id,
                           source_node_id,
                           transfer_id,
                           priority,
                           data);
}


/**
 * Remove the top event in the queue
 *
 * @param q
 */
void Request_Queue_Pop(request_queue_t *q){
  // Update queue pointers
  q->request[q->top].pending = false;
  q->size = MAX(0, (q->size - 1));
  q->top = (q->top + 1) % REQUEST_QUEUE_CAPACITY;
}
