/**
 * Created: 28 Nov 2018
 * Author: Stou Sandalski <stou@icapsid.net>
 *
 * Description: Simple stm32 interface to INA219
 *
 */


#include "ina219.h"
#include <stm32_util.h>

void INA219_Config(I2C_TypeDef *i2c,
                   uint16_t address_7_bit,
                   uint16_t config){

  uint8_t buffer[2] = {
      (uint8_t) (0xFF & (config >> 8)),
      (uint8_t) (0xFF & config)
  };

  I2C_Write_Register(i2c,
                     address_7_bit,
                     INA219_REGISTER_CONFIGURATION,
                     sizeof(buffer),
                     buffer);
}

void INA219_Readout(I2C_TypeDef *i2c,
                    uint16_t address_7_bit,
                    int32_t *V_shunt,
                    int32_t *V_bus){

  uint8_t buffer[2];

  // Disable IRQ Handling or an incoming CAN packet can fuck up the data reading
  __disable_irq();

  // There is no auto-increment support so registers have to be read separately.

  // Read Shunt voltage
  I2C_Read_Register(i2c,
                    address_7_bit,
                    INA219_REGISTER_VOLTAGE_SHUNT,
                    sizeof(buffer),
                    buffer);

  *V_shunt = buffer[1] | (buffer[0] << 8);

  // Shunt can be negative.
  if(*V_shunt & 0x8000){
    *V_shunt = -(uint16_t) (0x1U + ~*V_shunt);
  }

  // Read Bus Voltage
  I2C_Read_Register(i2c,
                    address_7_bit,
                    INA219_REGISTER_VOLTAGE_BUS,
                    sizeof(buffer),
                    buffer);

  *V_bus = (buffer[1] >> 3 | (buffer[0] << 5));

  __enable_irq();
}

/**
 *
 * @param hi2c
 * @param address_7_bit
 * @param V_bus
 */
int32_t INA219_Readout_Voltage(I2C_TypeDef *i2c,
                               uint16_t address_7_bit){

  uint8_t buffer[2];

  // Disable IRQ Handling or an incoming CAN packet can fuck up the data reading
  __disable_irq();

  // Read Bus Voltage
  I2C_Read_Register(i2c,
                    address_7_bit,
                    INA219_REGISTER_VOLTAGE_BUS,
                    sizeof(buffer),
                    buffer);

  __enable_irq();

  return (buffer[1] >> 3 | (buffer[0] << 5));
}
